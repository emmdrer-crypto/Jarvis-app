package com.example.ai

import android.graphics.Bitmap
import android.util.Log
import com.example.model.ChatMessage
import com.example.model.DisciplineChecklist
import com.example.model.TradeAnalysisResult
import com.example.model.VerdictType
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withTimeout
import org.json.JSONObject
import kotlin.math.max
import kotlin.math.roundToInt

private const val TAG = "JarvisAiRepo"
private const val MODEL_NAME = "gemini-3.8-flash"

class JarvisAiRepository {

    private val scanResponseSchema = Schema.obj(
        properties = mapOf(
            "verdict" to Schema.enumeration(
                values = listOf("GOOD SETUP", "WAIT", "NO TRADE"),
                description = "Overall trade verdict based on chart structure, risk/reward, and discipline checklist."
            ),
            "confidenceSummary" to Schema.string(
                description = "1-2 sentence executive verdict explaining why this is GOOD SETUP, WAIT, or NO TRADE."
            ),
            "marketStructureNotes" to Schema.string(
                description = "Concise technical breakdown of trend, key support/resistance, liquidity sweeps, candlestick momentum, or chart pattern."
            ),
            "entryZone" to Schema.string(
                description = "Suggested entry price zone or trigger condition (or 'No Entry' if NO TRADE)."
            ),
            "stopLossZone" to Schema.string(
                description = "Suggested invalidation / stop-loss level or structural anchor."
            ),
            "takeProfitZone" to Schema.string(
                description = "Suggested target / take-profit zones (TP1 / TP2) aiming for >= 1:2 R:R."
            ),
            "riskWarnings" to Schema.array(
                items = Schema.string(),
                description = "2 to 4 crisp risk warnings, invalidation triggers, or checklist gaps."
            )
        )
    )

    private val scanModel by lazy {
        Firebase.ai.generativeModel(
            modelName = MODEL_NAME,
            generationConfig = generationConfig {
                temperature = 0.2f
                responseMimeType = "application/json"
                responseSchema = scanResponseSchema
            },
            systemInstruction = content {
                text(
                    "You are J.A.R.V.I.S., an elite institutional-grade technical trading assistant. " +
                        "Evaluate trade setups with strict capital-preservation discipline. " +
                        "Never guarantee profits; frame setups as educational/paper-trading scenario analysis. " +
                        "If a chart screenshot is provided, inspect price action, market structure (HH/HL or LH/LL), " +
                        "supply/demand or support/resistance levels, liquidity sweeps, trendlines, and indicators visible on the chart. " +
                        "If checklist rules are missing (e.g., no SL/TP, <1:2 R:R, high-impact news <30m, or higher timeframe unconfirmed), " +
                        "factor those strictly into a WAIT or NO TRADE verdict. Be decisive, concise, and specific."
                )
            }
        )
    }

    private val chatModel by lazy {
        Firebase.ai.generativeModel(
            modelName = MODEL_NAME,
            generationConfig = generationConfig {
                temperature = 0.4f
            },
            systemInstruction = content {
                text(
                    "You are J.A.R.V.I.S., a sleek dark-terminal AI trading assistant. " +
                        "Give crisp, structured, disciplined answers about price action, market structure, " +
                        "liquidity, session timing, and risk management. Keep answers practical and concise, " +
                        "using short bullet points when helpful. Remind users when appropriate that insights are educational only."
                )
            }
        )
    }

    private val overlayChatModel by lazy {
        Firebase.ai.generativeModel(
            modelName = MODEL_NAME,
            generationConfig = generationConfig {
                temperature = 0.3f
                maxOutputTokens = 280
            },
            systemInstruction = content {
                text(
                    "You are J.A.R.V.I.S. in Live Screen-Share Overlay mode while the trader watches live charts. " +
                        "Respond in ultra-concise terminal style (max 3-4 short sentences or bullets) so it fits cleanly in a compact floating window."
                )
            }
        )
    }

    suspend fun analyzeTradeSetup(
        pair: String,
        timeframe: String,
        checklist: DisciplineChecklist,
        sessionSummary: String,
        chartBitmap: Bitmap?,
        additionalContext: String = ""
    ): Result<TradeAnalysisResult> {
        return try {
            val preparedBitmap = chartBitmap?.let { prepareBitmapForUpload(it) }
            val promptText = buildString {
                appendLine("Analyze this trading setup and return structured JSON.")
                appendLine("Pair / Ticker: $pair")
                appendLine("Timeframe: $timeframe")
                appendLine("Active Market Session: $sessionSummary")
                appendLine("Pre-Trade Discipline Checklist (${checklist.completedCount}/4 met):")
                appendLine("- Higher timeframe trend confirmed: ${if (checklist.higherTimeframeConfirmed) "YES" else "NO"}")
                appendLine("- At least 1:2 Risk-to-Reward ratio: ${if (checklist.minRiskRewardMet) "YES" else "NO"}")
                appendLine("- Clear Stop-Loss & Take-Profit levels set: ${if (checklist.clearSlTpSet) "YES" else "NO"}")
                appendLine("- No high-impact news in next 30 minutes: ${if (checklist.noHighImpactNews) "YES" else "NO"}")
                if (preparedBitmap != null) {
                    appendLine("A chart screenshot is attached. Read the visible candles, structure, levels, and any indicators carefully. If price labels are visible on the right axis, reference realistic Entry, SL, and TP levels from the chart; otherwise describe exact structural zones.")
                } else {
                    appendLine("No chart screenshot was attached. Evaluate based on the ticker, timeframe, session liquidity context, and discipline checklist. Note clearly in marketStructureNotes that visual chart confirmation is still required and suggest key levels/conditions to verify before entering.")
                }
                if (additionalContext.isNotBlank()) {
                    appendLine("Trader note: $additionalContext")
                }
            }

            val response = withTimeout(60_000L) {
                scanModel.generateContent(
                    content {
                        if (preparedBitmap != null) {
                            image(preparedBitmap)
                        }
                        text(promptText)
                    }
                )
            }

            val jsonText = response.text
                ?: return Result.failure(IllegalStateException("Gemini returned an empty response."))

            val json = JSONObject(jsonText)
            val verdict = VerdictType.fromRaw(json.optString("verdict", "WAIT"))
            val confidenceSummary = json.optString("confidenceSummary", "Review chart structure and risk rules.")
            val marketStructureNotes = json.optString("marketStructureNotes", "No structure notes returned.")
            val entryZone = json.optString("entryZone", "Wait for confirmation")
            val stopLossZone = json.optString("stopLossZone", "Beyond invalidation swing")
            val takeProfitZone = json.optString("takeProfitZone", "1:2+ R:R structural target")
            val warningsArray = json.optJSONArray("riskWarnings")
            val warnings = if (warningsArray != null) {
                (0 until warningsArray.length()).mapNotNull { idx ->
                    warningsArray.optString(idx).takeIf { it.isNotBlank() }
                }
            } else {
                emptyList()
            }

            Result.success(
                TradeAnalysisResult(
                    verdict = verdict,
                    confidenceSummary = confidenceSummary,
                    marketStructureNotes = marketStructureNotes,
                    entryZone = entryZone,
                    stopLossZone = stopLossZone,
                    takeProfitZone = takeProfitZone,
                    riskWarnings = warnings,
                    pair = pair.ifBlank { "EUR/USD" },
                    timeframe = timeframe
                )
            )
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Trade scan timed out", e)
            Result.failure(Exception("Scan timed out after 60 seconds. Check connection and try again."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Trade scan failed", e)
            Result.failure(Exception(e.localizedMessage ?: "Failed to analyze setup."))
        }
    }

    fun streamChatReply(
        userMessage: String,
        history: List<ChatMessage>,
        pair: String,
        timeframe: String,
        sessionSummary: String,
        latestVerdict: TradeAnalysisResult?,
        chartBitmap: Bitmap?
    ): Flow<String> = flow {
        val preparedBitmap = chartBitmap?.let { prepareBitmapForUpload(it) }
        val contextHeader = buildString {
            append("[Current Terminal Context] Pair: $pair | TF: $timeframe | Session: $sessionSummary")
            if (latestVerdict != null) {
                append(" | Last Scan Verdict: ${latestVerdict.verdict.label} (${latestVerdict.confidenceSummary})")
            }
        }

        val promptHistory = history
            .filter { !it.isStreaming && it.text.isNotBlank() }
            .takeLast(8)
            .joinToString("\n") { msg ->
                val speaker = if (msg.isUser) "Trader" else "J.A.R.V.I.S."
                "$speaker: ${msg.text}"
            }

        val fullPrompt = buildString {
            appendLine(contextHeader)
            if (promptHistory.isNotBlank()) {
                appendLine("Recent conversation:")
                appendLine(promptHistory)
            }
            appendLine("Trader question: $userMessage")
        }

        val buffer = StringBuilder()
        withTimeout(60_000L) {
            chatModel.generateContentStream(
                content {
                    if (preparedBitmap != null) {
                        image(preparedBitmap)
                    }
                    text(fullPrompt)
                }
            ).collect { chunk ->
                val delta = chunk.text.orEmpty()
                if (delta.isNotEmpty()) {
                    buffer.append(delta)
                    emit(buffer.toString())
                }
            }
        }
        if (buffer.isBlank()) {
            throw IllegalStateException("J.A.R.V.I.S. returned an empty response.")
        }
    }

    suspend fun askOverlayQuickQuestion(
        question: String,
        pair: String,
        timeframe: String,
        screenBitmap: Bitmap?
    ): Result<String> {
        return try {
            val preparedBitmap = screenBitmap?.let { prepareBitmapForUpload(it) }
            val response = withTimeout(45_000L) {
                overlayChatModel.generateContent(
                    content {
                        if (preparedBitmap != null) {
                            image(preparedBitmap)
                        }
                        text(
                            "Context: $pair on $timeframe. " +
                                (if (preparedBitmap != null) "Current chart screen frame is attached. " else "") +
                                "Trader asks: $question"
                        )
                    }
                )
            }
            val text = response.text?.trim()
            if (text.isNullOrBlank()) {
                Result.failure(IllegalStateException("Empty reply from J.A.R.V.I.S."))
            } else {
                Result.success(text)
            }
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Overlay chat timed out", e)
            Result.failure(Exception("Timed out. Try again."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Overlay chat failed", e)
            Result.failure(Exception(e.localizedMessage ?: "Error getting response."))
        }
    }

    private fun prepareBitmapForUpload(source: Bitmap): Bitmap {
        val maxDim = 1280
        val width = source.width
        val height = source.height
        if (width <= maxDim && height <= maxDim) {
            return source
        }
        val scale = maxDim.toFloat() / max(width, height).toFloat()
        val targetW = (width * scale).roundToInt().coerceAtLeast(1)
        val targetH = (height * scale).roundToInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(source, targetW, targetH, true)
    }
}
