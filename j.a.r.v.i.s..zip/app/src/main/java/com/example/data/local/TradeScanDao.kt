package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface TradeScanDao {
    @Query("SELECT * FROM trade_scans ORDER BY timestamp DESC")
    fun observeAllScans(): Flow<List<TradeScanEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScan(scan: TradeScanEntity): Long

    @Query("UPDATE trade_scans SET outcome = :outcome WHERE id = :id")
    suspend fun updateOutcome(id: Long, outcome: String)

    @Query("DELETE FROM trade_scans WHERE id = :id")
    suspend fun deleteScanById(id: Long)

    @Query("DELETE FROM trade_scans")
    suspend fun clearAll()
}
