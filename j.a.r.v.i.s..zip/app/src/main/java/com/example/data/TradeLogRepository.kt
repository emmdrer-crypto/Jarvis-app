package com.example.data

import com.example.data.local.TradeScanDao
import com.example.data.local.TradeScanEntity
import com.example.model.DisciplineChecklist
import com.example.model.TradeAnalysisResult
import com.example.model.TradeOutcome
import kotlinx.coroutines.flow.Flow

class TradeLogRepository(private val dao: TradeScanDao) {
    val allScans: Flow<List<TradeScanEntity>> = dao.observeAllScans()

    suspend fun saveScan(
        result: TradeAnalysisResult,
        checklist: DisciplineChecklist,
        source: String
    ) {
        val entity = TradeScanEntity(
            pair = result.pair,
            timeframe = result.timeframe,
            verdict = result.verdict.name,
            confidenceSummary = result.confidenceSummary,
            marketStructureNotes = result.marketStructureNotes,
            entryZone = result.entryZone,
            stopLossZone = result.stopLossZone,
            takeProfitZone = result.takeProfitZone,
            riskWarnings = result.riskWarnings.joinToString("\n"),
            higherTimeframeConfirmed = checklist.higherTimeframeConfirmed,
            minRiskRewardMet = checklist.minRiskRewardMet,
            clearSlTpSet = checklist.clearSlTpSet,
            noHighImpactNews = checklist.noHighImpactNews,
            source = source,
            outcome = TradeOutcome.PENDING.name,
            timestamp = result.timestamp
        )
        dao.insertScan(entity)
    }

    suspend fun updateOutcome(id: Long, outcome: TradeOutcome) {
        dao.updateOutcome(id, outcome.name)
    }

    suspend fun deleteScan(id: Long) {
        dao.deleteScanById(id)
    }

    suspend fun clearAll() {
        dao.clearAll()
    }
}
