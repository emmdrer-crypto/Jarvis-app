package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.model.TradeOutcome

@Entity(tableName = "trade_scans")
data class TradeScanEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val pair: String,
    val timeframe: String,
    val verdict: String, // GOOD_SETUP, WAIT, NO_TRADE
    val confidenceSummary: String,
    val marketStructureNotes: String,
    val entryZone: String,
    val stopLossZone: String,
    val takeProfitZone: String,
    val riskWarnings: String, // newline-delimited warnings
    val higherTimeframeConfirmed: Boolean,
    val minRiskRewardMet: Boolean,
    val clearSlTpSet: Boolean,
    val noHighImpactNews: Boolean,
    val source: String, // SCANNER or SCREEN_SNAP
    val outcome: String = TradeOutcome.PENDING.name,
    val timestamp: Long = System.currentTimeMillis()
) {
    val rulesMetCount: Int
        get() = listOf(
            higherTimeframeConfirmed,
            minRiskRewardMet,
            clearSlTpSet,
            noHighImpactNews
        ).count { it }
}
