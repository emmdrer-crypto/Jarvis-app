package com.example.overlay

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.text.TextUtils
import android.util.DisplayMetrics
import android.util.Log
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.ai.JarvisAiRepository
import com.example.data.TradeLogRepository
import com.example.data.local.JarvisDatabase
import com.example.model.VerdictType
import com.example.util.TradingSessions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.roundToInt

class ScreenShareOverlayService : Service() {

    companion object {
        private const val TAG = "ScreenShareOverlaySvc"
        private const val CHANNEL_ID = "jarvis_screen_share_channel"
        private const val NOTIFICATION_ID = 4041

        const val ACTION_START = "com.example.overlay.ACTION_START"
        const val ACTION_STOP = "com.example.overlay.ACTION_STOP"
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_DATA_INTENT = "extra_data_intent"

        fun createStartIntent(context: Context, resultCode: Int, data: Intent): Intent {
            return Intent(context, ScreenShareOverlayService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_RESULT_CODE, resultCode)
                putExtra(EXTRA_DATA_INTENT, data)
            }
        }

        fun createStopIntent(context: Context): Intent {
            return Intent(context, ScreenShareOverlayService::class.java).apply {
                action = ACTION_STOP
            }
        }
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val aiRepository by lazy { JarvisAiRepository() }
    private val tradeLogRepository by lazy {
        TradeLogRepository(JarvisDatabase.getInstance(applicationContext).tradeScanDao())
    }

    private var windowManager: WindowManager? = null
    private var overlayRoot: LinearLayout? = null
    private var layoutParams: WindowManager.LayoutParams? = null

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var captureThread: HandlerThread? = null
    private var captureHandler: Handler? = null

    private val frameLock = Any()
    @Volatile
    private var latestFrameBitmap: Bitmap? = null

    private var isCollapsed = false
    private var captureWidth = 720
    private var captureHeight = 1280
    private var captureDensityDpi = 320

    // Overlay UI references
    private var bodyContainer: LinearLayout? = null
    private var collapseBtn: TextView? = null
    private var contextBadgeView: TextView? = null
    private var snapButton: Button? = null
    private var verdictBadgeView: TextView? = null
    private var snapSummaryView: TextView? = null
    private var chatScrollView: ScrollView? = null
    private var chatMessagesContainer: LinearLayout? = null
    private var chatInputEditText: EditText? = null
    private var chatSendButton: Button? = null

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            Log.d(TAG, "MediaProjection stopped by system")
            stopOverlayAndSelf()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopOverlayAndSelf()
            return START_NOT_STICKY
        }

        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
            ?: Activity.RESULT_CANCELED
        @Suppress("DEPRECATION")
        val dataIntent: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent?.getParcelableExtra(EXTRA_DATA_INTENT, Intent::class.java)
        } else {
            intent?.getParcelableExtra(EXTRA_DATA_INTENT)
        }

        if (resultCode != Activity.RESULT_OK || dataIntent == null) {
            Log.e(TAG, "Invalid MediaProjection resultCode or dataIntent")
            ScreenShareStateHolder.setError("Screen capture permission was not granted.")
            stopOverlayAndSelf()
            return START_NOT_STICKY
        }

        try {
            setupMediaProjection(resultCode, dataIntent)
            if (overlayRoot == null) {
                attachOverlayWindow()
                observeOverlayState()
            }
            ScreenShareStateHolder.setSharing(true)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start screen share overlay", e)
            ScreenShareStateHolder.setError(e.localizedMessage ?: "Unable to start screen capture.")
            stopOverlayAndSelf()
        }

        return START_NOT_STICKY
    }

    private fun setupMediaProjection(resultCode: Int, data: Intent) {
        tearDownProjection()

        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager?.defaultDisplay?.getRealMetrics(metrics)
        val rawW = metrics.widthPixels.coerceAtLeast(720)
        val rawH = metrics.heightPixels.coerceAtLeast(1280)
        captureDensityDpi = metrics.densityDpi.coerceAtLeast(160)

        val maxDim = 1080
        val scale = if (max(rawW, rawH) > maxDim) {
            maxDim.toFloat() / max(rawW, rawH).toFloat()
        } else {
            1f
        }
        captureWidth = (rawW * scale).roundToInt().coerceAtLeast(360)
        captureHeight = (rawH * scale).roundToInt().coerceAtLeast(360)

        val thread = HandlerThread("JarvisScreenCapture").apply { start() }
        captureThread = thread
        val handler = Handler(thread.looper)
        captureHandler = handler

        val mpManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val projection = mpManager.getMediaProjection(resultCode, data)
            ?: throw IllegalStateException("MediaProjection returned null")
        mediaProjection = projection
        projection.registerCallback(projectionCallback, Handler(Looper.getMainLooper()))

        val reader = ImageReader.newInstance(captureWidth, captureHeight, PixelFormat.RGBA_8888, 2)
        imageReader = reader
        reader.setOnImageAvailableListener({ r ->
            var image: Image? = null
            try {
                image = r.acquireLatestImage()
                if (image != null) {
                    val bmp = imageToBitmap(image)
                    if (bmp != null) {
                        synchronized(frameLock) {
                            latestFrameBitmap = bmp
                        }
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Frame acquire warning: ${e.message}")
            } finally {
                image?.close()
            }
        }, handler)

        virtualDisplay = projection.createVirtualDisplay(
            "JarvisChartCapture",
            captureWidth,
            captureHeight,
            captureDensityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface,
            null,
            handler
        )
    }

    private fun imageToBitmap(image: Image): Bitmap? {
        val plane = image.planes.firstOrNull() ?: return null
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width
        val paddedWidth = image.width + rowPadding / pixelStride
        val tempBitmap = Bitmap.createBitmap(paddedWidth, image.height, Bitmap.Config.ARGB_8888)
        tempBitmap.copyPixelsFromBuffer(buffer)
        return if (paddedWidth == image.width) {
            tempBitmap
        } else {
            Bitmap.createBitmap(tempBitmap, 0, 0, image.width, image.height)
        }
    }

    private fun dp(value: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            resources.displayMetrics
        ).roundToInt()
    }

    private fun makeRoundedBg(
        fillColor: Int,
        strokeColor: Int? = null,
        strokeWidthDp: Int = 1,
        radiusDp: Int = 14
    ): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(radiusDp).toFloat()
            setColor(fillColor)
            if (strokeColor != null) {
                setStroke(dp(strokeWidthDp), strokeColor)
            }
        }
    }

    private fun attachOverlayWindow() {
        val windowType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val widthPx = (resources.displayMetrics.widthPixels * 0.84f)
            .roundToInt()
            .coerceIn(dp(290), dp(380))

        val params = WindowManager.LayoutParams(
            widthPx,
            WindowManager.LayoutParams.WRAP_CONTENT,
            windowType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(16)
            y = dp(90)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        layoutParams = params

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = makeRoundedBg(
                fillColor = Color.parseColor("#F20A1019"),
                strokeColor = Color.parseColor("#CC00E5FF"),
                strokeWidthDp = 1,
                radiusDp = 18
            )
            setPadding(dp(12), dp(10), dp(12), dp(12))
            elevation = dp(12).toFloat()
        }
        overlayRoot = root

        // Header bar (Draggable)
        val headerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        val dragTitle = TextView(this).apply {
            text = "⋮⋮ J.A.R.V.I.S."
            setTextColor(Color.parseColor("#00E5FF"))
            textSize = 13f
            typeface = Typeface.MONOSPACE
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(4), dp(6), dp(4))
        }

        val ctxBadge = TextView(this).apply {
            text = "EUR/USD • 15m"
            setTextColor(Color.parseColor("#94A7C2"))
            textSize = 11f
            typeface = Typeface.MONOSPACE
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        contextBadgeView = ctxBadge

        val collapseToggle = TextView(this).apply {
            text = "—"
            setTextColor(Color.parseColor("#F1F5FB"))
            textSize = 14f
            gravity = Gravity.CENTER
            background = makeRoundedBg(Color.parseColor("#1A2639"), radiusDp = 8)
            val lp = LinearLayout.LayoutParams(dp(34), dp(34)).apply {
                marginEnd = dp(6)
            }
            layoutParams = lp
            setOnClickListener { toggleCollapse() }
        }
        collapseBtn = collapseToggle

        val stopBtn = Button(this).apply {
            text = "Stop Sharing"
            setTextColor(Color.WHITE)
            textSize = 11f
            isAllCaps = false
            typeface = Typeface.DEFAULT_BOLD
            background = makeRoundedBg(Color.parseColor("#D9263E"), radiusDp = 8)
            setPadding(dp(10), dp(4), dp(10), dp(4))
            minHeight = dp(34)
            minimumHeight = dp(34)
            minWidth = 0
            minimumWidth = 0
            setOnClickListener { stopOverlayAndSelf() }
        }

        headerRow.addView(dragTitle)
        headerRow.addView(ctxBadge)
        headerRow.addView(collapseToggle)
        headerRow.addView(stopBtn)
        attachDragTouchListener(headerRow)
        root.addView(headerRow)

        // Body container
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(8)
            }
        }
        bodyContainer = body

        // Snap & Check + Verdict Row
        val snapBtn = Button(this).apply {
            text = "⚡ Snap & Check Chart"
            setTextColor(Color.parseColor("#00181F"))
            textSize = 13f
            isAllCaps = false
            typeface = Typeface.DEFAULT_BOLD
            background = makeRoundedBg(Color.parseColor("#00E5FF"), radiusDp = 12)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(46)
            )
            setOnClickListener { triggerSnapAndCheck() }
        }
        snapButton = snapBtn
        body.addView(snapBtn)

        val verdictRow = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = makeRoundedBg(
                fillColor = Color.parseColor("#141C2B"),
                strokeColor = Color.parseColor("#24334B"),
                radiusDp = 10
            )
            setPadding(dp(10), dp(8), dp(10), dp(8))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(8)
            }
        }

        val vBadge = TextView(this).apply {
            text = "READY TO SCAN"
            setTextColor(Color.parseColor("#00E5FF"))
            textSize = 11f
            typeface = Typeface.MONOSPACE
            setTypeface(typeface, Typeface.BOLD)
        }
        verdictBadgeView = vBadge

        val vSummary = TextView(this).apply {
            text = "Open TradingView or MT5 and tap Snap & Check."
            setTextColor(Color.parseColor("#DCE6F5"))
            textSize = 12f
            maxLines = 5
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(2) }
        }
        snapSummaryView = vSummary

        verdictRow.addView(vBadge)
        verdictRow.addView(vSummary)
        body.addView(verdictRow)

        // Mini Live Chat Log
        val chatScroll = ScrollView(this).apply {
            background = makeRoundedBg(
                fillColor = Color.parseColor("#0D131E"),
                strokeColor = Color.parseColor("#1D2A3E"),
                radiusDp = 10
            )
            setPadding(dp(8), dp(6), dp(8), dp(6))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(120)
            ).apply {
                topMargin = dp(8)
            }
        }
        chatScrollView = chatScroll

        val chatList = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        chatMessagesContainer = chatList
        chatScroll.addView(chatList)
        body.addView(chatScroll)

        // Mini Chat Input Row
        val inputRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(8)
            }
        }

        val inputEt = EditText(this).apply {
            hint = "Ask J.A.R.V.I.S.…"
            setHintTextColor(Color.parseColor("#6A7D99"))
            setTextColor(Color.parseColor("#F1F5FB"))
            textSize = 13f
            setSingleLine(true)
            imeOptions = EditorInfo.IME_ACTION_SEND
            background = makeRoundedBg(
                fillColor = Color.parseColor("#141D2C"),
                strokeColor = Color.parseColor("#2A3B56"),
                radiusDp = 10
            )
            setPadding(dp(10), dp(8), dp(10), dp(8))
            layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f).apply {
                marginEnd = dp(6)
            }
            setOnTouchListener { v, event ->
                if (event.action == MotionEvent.ACTION_UP) {
                    enableWindowFocusForKeyboard(v)
                }
                false
            }
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_SEND) {
                    sendOverlayChatMessage()
                    true
                } else {
                    false
                }
            }
        }
        chatInputEditText = inputEt

        val sendBtn = Button(this).apply {
            text = "Ask"
            setTextColor(Color.parseColor("#00181F"))
            textSize = 12f
            isAllCaps = false
            typeface = Typeface.DEFAULT_BOLD
            background = makeRoundedBg(Color.parseColor("#00E676"), radiusDp = 10)
            minWidth = dp(56)
            minimumWidth = dp(56)
            layoutParams = LinearLayout.LayoutParams(dp(58), dp(44))
            setOnClickListener { sendOverlayChatMessage() }
        }
        chatSendButton = sendBtn

        inputRow.addView(inputEt)
        inputRow.addView(sendBtn)
        body.addView(inputRow)

        root.addView(body)
        windowManager?.addView(root, params)
    }

    private fun enableWindowFocusForKeyboard(targetView: View) {
        val params = layoutParams ?: return
        val root = overlayRoot ?: return
        if ((params.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE) != 0) {
            params.flags = params.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
            windowManager?.updateViewLayout(root, params)
        }
        targetView.requestFocus()
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        targetView.postDelayed({
            imm.showSoftInput(targetView, InputMethodManager.SHOW_IMPLICIT)
        }, 60)
    }

    private fun releaseWindowFocus() {
        val params = layoutParams ?: return
        val root = overlayRoot ?: return
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        chatInputEditText?.let { imm.hideSoftInputFromWindow(it.windowToken, 0) }
        if ((params.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE) == 0) {
            params.flags = params.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            windowManager?.updateViewLayout(root, params)
        }
    }

    private fun toggleCollapse() {
        isCollapsed = !isCollapsed
        bodyContainer?.visibility = if (isCollapsed) View.GONE else View.VISIBLE
        collapseBtn?.text = if (isCollapsed) "+" else "—"
        if (isCollapsed) {
            releaseWindowFocus()
        }
    }

    private fun attachDragTouchListener(dragTarget: View) {
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f

        dragTarget.setOnTouchListener { _, event ->
            val params = layoutParams ?: return@setOnTouchListener false
            val root = overlayRoot ?: return@setOnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - initialTouchX).roundToInt()
                    params.y = initialY + (event.rawY - initialTouchY).roundToInt()
                    windowManager?.updateViewLayout(root, params)
                    true
                }
                else -> false
            }
        }
    }

    private fun observeOverlayState() {
        serviceScope.launch {
            ScreenShareStateHolder.state.collectLatest { state ->
                contextBadgeView?.text = "${state.activePair} • ${state.activeTimeframe}"

                snapButton?.isEnabled = !state.isAnalyzingSnap
                snapButton?.text = if (state.isAnalyzingSnap) {
                    "Analyzing Chart…"
                } else {
                    "⚡ Snap & Check Chart"
                }

                val snap = state.lastSnapResult
                if (snap != null && !state.isAnalyzingSnap) {
                    val colorHex = when (snap.verdict) {
                        VerdictType.GOOD_SETUP -> "#00E676"
                        VerdictType.WAIT -> "#FFB300"
                        VerdictType.NO_TRADE -> "#FF3D57"
                    }
                    verdictBadgeView?.setTextColor(Color.parseColor(colorHex))
                    verdictBadgeView?.text = "${snap.verdict.label} • ${snap.pair}"
                    snapSummaryView?.text =
                        "${snap.confidenceSummary}\nEntry: ${snap.entryZone} | SL: ${snap.stopLossZone} | TP: ${snap.takeProfitZone}"
                } else {
                    verdictBadgeView?.setTextColor(Color.parseColor("#00E5FF"))
                    verdictBadgeView?.text = if (state.isAnalyzingSnap) "SCANNING SCREEN…" else "LIVE OVERLAY READY"
                    snapSummaryView?.text = state.statusNote
                }

                chatSendButton?.isEnabled = !state.isChatSending
                chatSendButton?.text = if (state.isChatSending) "…" else "Ask"

                renderChatLines(state.overlayChatLines)
            }
        }
    }

    private fun renderChatLines(lines: List<OverlayChatLine>) {
        val container = chatMessagesContainer ?: return
        container.removeAllViews()
        if (lines.isEmpty()) {
            val emptyHint = TextView(this).apply {
                text = "Live mini-chat: ask about trend, S/R levels, or risk without leaving your chart."
                setTextColor(Color.parseColor("#7387A6"))
                textSize = 11f
            }
            container.addView(emptyHint)
            return
        }
        lines.forEach { line ->
            val tv = TextView(this).apply {
                text = if (line.isUser) "You: ${line.text}" else "J.A.R.V.I.S.: ${line.text}"
                setTextColor(
                    if (line.isUser) Color.parseColor("#00E5FF") else Color.parseColor("#E6EEF8")
                )
                textSize = 11.5f
                setPadding(dp(4), dp(3), dp(4), dp(3))
            }
            container.addView(tv)
        }
        chatScrollView?.post {
            chatScrollView?.fullScroll(View.FOCUS_DOWN)
        }
    }

    private fun captureCleanScreenFrame(): Bitmap? {
        return synchronized(frameLock) { latestFrameBitmap }
    }

    private fun triggerSnapAndCheck() {
        val currentState = ScreenShareStateHolder.state.value
        if (currentState.isAnalyzingSnap) return

        releaseWindowFocus()
        serviceScope.launch {
            ScreenShareStateHolder.setAnalyzingSnap(true, "Capturing live chart frame…")
            // Briefly hide overlay so the underlying chart is unobstructed
            overlayRoot?.visibility = View.INVISIBLE
            delay(180L)
            val capturedBitmap = captureCleanScreenFrame()
            overlayRoot?.visibility = View.VISIBLE

            if (capturedBitmap == null) {
                ScreenShareStateHolder.setError("No screen frame ready yet. Scroll/tap your chart and retry.")
                return@launch
            }

            ScreenShareStateHolder.setAnalyzingSnap(true, "J.A.R.V.I.S. inspecting chart…")
            val sessionLabel = TradingSessions.currentSnapshot().activeSummaryLabel
            val result = withContext(Dispatchers.IO) {
                aiRepository.analyzeTradeSetup(
                    pair = currentState.activePair,
                    timeframe = currentState.activeTimeframe,
                    checklist = currentState.activeChecklist,
                    sessionSummary = sessionLabel,
                    chartBitmap = capturedBitmap,
                    additionalContext = "Captured via Live Screen-Share Snap & Check over external chart app."
                )
            }

            result.fold(
                onSuccess = { analysis ->
                    ScreenShareStateHolder.setSnapResult(analysis)
                    withContext(Dispatchers.IO) {
                        tradeLogRepository.saveScan(
                            result = analysis,
                            checklist = currentState.activeChecklist,
                            source = "SCREEN_SNAP"
                        )
                    }
                },
                onFailure = { err ->
                    ScreenShareStateHolder.setError(err.localizedMessage ?: "Snap scan failed.")
                }
            )
        }
    }

    private fun sendOverlayChatMessage() {
        val question = chatInputEditText?.text?.toString()?.trim().orEmpty()
        if (question.isBlank()) return
        val currentState = ScreenShareStateHolder.state.value
        if (currentState.isChatSending) return

        chatInputEditText?.setText("")
        releaseWindowFocus()
        ScreenShareStateHolder.appendChatLine(OverlayChatLine(isUser = true, text = question))
        ScreenShareStateHolder.setChatSending(true)

        serviceScope.launch {
            val frame = captureCleanScreenFrame()
            val reply = withContext(Dispatchers.IO) {
                aiRepository.askOverlayQuickQuestion(
                    question = question,
                    pair = currentState.activePair,
                    timeframe = currentState.activeTimeframe,
                    screenBitmap = frame
                )
            }
            ScreenShareStateHolder.setChatSending(false)
            reply.fold(
                onSuccess = { answer ->
                    ScreenShareStateHolder.appendChatLine(OverlayChatLine(isUser = false, text = answer))
                },
                onFailure = { err ->
                    ScreenShareStateHolder.appendChatLine(
                        OverlayChatLine(
                            isUser = false,
                            text = "Error: ${err.localizedMessage ?: "Unable to reply"}"
                        )
                    )
                }
            )
        }
    }

    private fun stopOverlayAndSelf() {
        ScreenShareStateHolder.setSharing(false)
        removeOverlayWindow()
        tearDownProjection()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun removeOverlayWindow() {
        val root = overlayRoot
        overlayRoot = null
        if (root != null) {
            try {
                windowManager?.removeView(root)
            } catch (e: Exception) {
                Log.w(TAG, "Error removing overlay view: ${e.message}")
            }
        }
    }

    private fun tearDownProjection() {
        try {
            virtualDisplay?.release()
        } catch (_: Exception) {
        }
        virtualDisplay = null

        try {
            imageReader?.setOnImageAvailableListener(null, null)
            imageReader?.close()
        } catch (_: Exception) {
        }
        imageReader = null

        try {
            mediaProjection?.unregisterCallback(projectionCallback)
            mediaProjection?.stop()
        } catch (_: Exception) {
        }
        mediaProjection = null

        try {
            captureThread?.quitSafely()
        } catch (_: Exception) {
        }
        captureThread = null
        captureHandler = null
    }

    override fun onDestroy() {
        ScreenShareStateHolder.setSharing(false)
        removeOverlayWindow()
        tearDownProjection()
        serviceScope.cancel()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.overlay_notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            )
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openAppIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            createStopIntent(this),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.overlay_notification_title))
            .setContentText(getString(R.string.overlay_notification_text))
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(openAppIntent)
            .addAction(0, getString(R.string.action_stop_sharing), stopPendingIntent)
            .setOngoing(true)
            .build()
    }
}
