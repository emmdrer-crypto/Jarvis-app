package com.example.overlay

import com.example.model.DisciplineChecklist
import com.example.model.TradeAnalysisResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class OverlayChatLine(
    val isUser: Boolean,
    val text: String
)

data class ScreenShareUiState(
    val isSharing: Boolean = false,
    val isAnalyzingSnap: Boolean = false,
    val isChatSending: Boolean = false,
    val activePair: String = "EUR/USD",
    val activeTimeframe: String = "15m",
    val activeChecklist: DisciplineChecklist = DisciplineChecklist(),
    val lastSnapResult: TradeAnalysisResult? = null,
    val statusNote: String = "Tap Snap & Check while viewing your chart.",
    val overlayChatLines: List<OverlayChatLine> = emptyList()
)

object ScreenShareStateHolder {
    private val _state = MutableStateFlow(ScreenShareUiState())
    val state: StateFlow<ScreenShareUiState> = _state.asStateFlow()

    fun updateScannerContext(
        pair: String,
        timeframe: String,
        checklist: DisciplineChecklist
    ) {
        _state.update {
            it.copy(
                activePair = pair.ifBlank { "EUR/USD" },
                activeTimeframe = timeframe,
                activeChecklist = checklist
            )
        }
    }

    fun setSharing(active: Boolean) {
        _state.update {
            if (active) {
                it.copy(
                    isSharing = true,
                    statusNote = "Live over apps. Tap Snap & Check on any chart."
                )
            } else {
                it.copy(
                    isSharing = false,
                    isAnalyzingSnap = false,
                    isChatSending = false
                )
            }
        }
    }

    fun setAnalyzingSnap(analyzing: Boolean, note: String? = null) {
        _state.update {
            it.copy(
                isAnalyzingSnap = analyzing,
                statusNote = note ?: it.statusNote
            )
        }
    }

    fun setSnapResult(result: TradeAnalysisResult) {
        _state.update {
            it.copy(
                isAnalyzingSnap = false,
                lastSnapResult = result,
                statusNote = "${result.verdict.label}: ${result.confidenceSummary}"
            )
        }
    }

    fun setError(message: String) {
        _state.update {
            it.copy(
                isAnalyzingSnap = false,
                isChatSending = false,
                statusNote = "Error: $message"
            )
        }
    }

    fun setChatSending(sending: Boolean) {
        _state.update { it.copy(isChatSending = sending) }
    }

    fun appendChatLine(line: OverlayChatLine) {
        _state.update {
            it.copy(
                overlayChatLines = (it.overlayChatLines + line).takeLast(12)
            )
        }
    }
}
