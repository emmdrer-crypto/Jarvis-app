package com.example.model

enum class VerdictType(val label: String) {
    GOOD_SETUP("GOOD SETUP"),
    WAIT("WAIT"),
    NO_TRADE("NO TRADE");

    companion object {
        fun fromRaw(raw: String): VerdictType {
            val normalized = raw.trim().uppercase()
            return when {
                normalized.contains("GOOD") -> GOOD_SETUP
                normalized.contains("WAIT") -> WAIT
                else -> NO_TRADE
            }
        }
    }
}

enum class TimeframeOption(val label: String) {
    M1("1m"),
    M5("5m"),
    M15("15m"),
    H1("1H"),
    H4("4H"),
    D1("1D")
}

data class DisciplineChecklist(
    val higherTimeframeConfirmed: Boolean = false,
    val minRiskRewardMet: Boolean = false,
    val clearSlTpSet: Boolean = false,
    val noHighImpactNews: Boolean = false
) {
    val completedCount: Int
        get() = listOf(
            higherTimeframeConfirmed,
            minRiskRewardMet,
            clearSlTpSet,
            noHighImpactNews
        ).count { it }

    val allMet: Boolean
        get() = completedCount == 4
}

data class TradeAnalysisResult(
    val verdict: VerdictType,
    val confidenceSummary: String,
    val marketStructureNotes: String,
    val entryZone: String,
    val stopLossZone: String,
    val takeProfitZone: String,
    val riskWarnings: List<String>,
    val pair: String,
    val timeframe: String,
    val timestamp: Long = System.currentTimeMillis()
)

sealed interface ScanUiState {
    data object Idle : ScanUiState
    data object Scanning : ScanUiState
    data class Success(val result: TradeAnalysisResult) : ScanUiState
    data class Error(val message: String) : ScanUiState
}

data class ChatMessage(
    val id: String,
    val isUser: Boolean,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isStreaming: Boolean = false
)

enum class InstrumentPreset(
    val label: String,
    val unitLabel: String,
    val defaultValuePerUnitPerLot: Double,
    val stopLabel: String
) {
    FOREX_STANDARD("Forex Std (EUR/USD)", "Lots", 10.0, "Stop-Loss (Pips)"),
    FOREX_JPY("Forex JPY (USD/JPY)", "Lots", 6.8, "Stop-Loss (Pips)"),
    GOLD_XAU("Gold (XAU/USD)", "Lots", 10.0, "Stop-Loss (Pips / $0.10)"),
    INDICES_CRYPTO("Indices / Crypto / Stocks", "Units/Contracts", 1.0, "Stop-Loss (Points / $)")
}

data class PositionCalcResult(
    val dollarRisk: Double,
    val positionSize: Double,
    val unitLabel: String,
    val subUnitDetail: String,
    val target2RProfit: Double,
    val target3RProfit: Double,
    val riskLevelLabel: String
)

enum class SessionStatus {
    OPEN,
    OVERLAP_PEAK,
    CLOSED
}

data class TradingSessionInfo(
    val name: String,
    val regionTag: String,
    val openHourUtc: Int,
    val closeHourUtc: Int,
    val status: SessionStatus,
    val localTimeRange: String,
    val statusDetail: String,
    val volatilityNote: String
)

data class OverlapWindowInfo(
    val title: String,
    val utcWindow: String,
    val isActive: Boolean,
    val description: String
)

enum class TradeOutcome(val label: String) {
    PENDING("Pending"),
    TOOK_WIN("Took • Win"),
    TOOK_LOSS("Took • Loss"),
    TOOK_BE("Took • BE"),
    SKIPPED("Skipped")
}
