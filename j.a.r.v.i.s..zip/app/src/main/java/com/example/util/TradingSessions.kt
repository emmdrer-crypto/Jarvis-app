package com.example.util

import com.example.model.OverlapWindowInfo
import com.example.model.SessionStatus
import com.example.model.TradingSessionInfo
import java.time.Instant
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

data class SessionSnapshot(
    val utcTimeFormatted: String,
    val localTimeFormatted: String,
    val localZoneLabel: String,
    val activeSummaryLabel: String,
    val isOverlapActive: Boolean,
    val sessions: List<TradingSessionInfo>,
    val overlaps: List<OverlapWindowInfo>,
    val macroWindows: List<MacroWindowNote>
)

data class MacroWindowNote(
    val title: String,
    val utcWindow: String,
    val detail: String,
    val isNow: Boolean
)

object TradingSessions {
    private val timeFormatter = DateTimeFormatter.ofPattern("HH:mm:ss")
    private val shortTimeFormatter = DateTimeFormatter.ofPattern("HH:mm")

    fun currentSnapshot(nowMillis: Long = System.currentTimeMillis()): SessionSnapshot {
        val instant = Instant.ofEpochMilli(nowMillis)
        val utcNow = ZonedDateTime.ofInstant(instant, ZoneOffset.UTC)
        val localZone = ZoneId.systemDefault()
        val localNow = ZonedDateTime.ofInstant(instant, localZone)

        val utcHour = utcNow.hour
        val utcMinute = utcNow.minute
        val utcMinutesOfDay = utcHour * 60 + utcMinute

        val isSydneyOpen = isHourInWindow(utcHour, 21, 6)
        val isTokyoOpen = isHourInWindow(utcHour, 0, 9)
        val isLondonOpen = isHourInWindow(utcHour, 7, 16)
        val isNewYorkOpen = isHourInWindow(utcHour, 12, 21)

        val isLondonNyOverlap = isLondonOpen && isNewYorkOpen // 12:00 - 16:00 UTC
        val isTokyoLondonOverlap = isTokyoOpen && isLondonOpen // 07:00 - 09:00 UTC
        val isAnyOverlap = isLondonNyOverlap || isTokyoLondonOverlap

        val sessions = listOf(
            TradingSessionInfo(
                name = "Asian (Tokyo)",
                regionTag = "TYO",
                openHourUtc = 0,
                closeHourUtc = 9,
                status = when {
                    isTokyoLondonOverlap -> SessionStatus.OVERLAP_PEAK
                    isTokyoOpen -> SessionStatus.OPEN
                    else -> SessionStatus.CLOSED
                },
                localTimeRange = formatUtcWindowToLocal(0, 9, localZone),
                statusDetail = buildStatusDetail(utcMinutesOfDay, 0, 9, isTokyoOpen),
                volatilityNote = "JPY, AUD, NZD pairs • Watch Asian range highs/lows for London sweeps"
            ),
            TradingSessionInfo(
                name = "London",
                regionTag = "LDN",
                openHourUtc = 7,
                closeHourUtc = 16,
                status = when {
                    isLondonNyOverlap || isTokyoLondonOverlap -> SessionStatus.OVERLAP_PEAK
                    isLondonOpen -> SessionStatus.OPEN
                    else -> SessionStatus.CLOSED
                },
                localTimeRange = formatUtcWindowToLocal(7, 16, localZone),
                statusDetail = buildStatusDetail(utcMinutesOfDay, 7, 16, isLondonOpen),
                volatilityNote = "EUR, GBP, XAU pairs • Peak morning expansion 07:00–10:00 UTC"
            ),
            TradingSessionInfo(
                name = "New York",
                regionTag = "NYC",
                openHourUtc = 12,
                closeHourUtc = 21,
                status = when {
                    isLondonNyOverlap -> SessionStatus.OVERLAP_PEAK
                    isNewYorkOpen -> SessionStatus.OPEN
                    else -> SessionStatus.CLOSED
                },
                localTimeRange = formatUtcWindowToLocal(12, 21, localZone),
                statusDetail = buildStatusDetail(utcMinutesOfDay, 12, 21, isNewYorkOpen),
                volatilityNote = "USD, US Indices, Gold • Equities cash open 13:30/14:30 UTC"
            ),
            TradingSessionInfo(
                name = "Sydney",
                regionTag = "SYD",
                openHourUtc = 21,
                closeHourUtc = 6,
                status = if (isSydneyOpen) SessionStatus.OPEN else SessionStatus.CLOSED,
                localTimeRange = formatUtcWindowToLocal(21, 6, localZone),
                statusDetail = buildStatusDetail(utcMinutesOfDay, 21, 6, isSydneyOpen),
                volatilityNote = "AUD, NZD pairs • Lower liquidity rollover transition"
            )
        )

        val overlaps = listOf(
            OverlapWindowInfo(
                title = "London / New York Overlap",
                utcWindow = "12:00 – 16:00 UTC (${formatUtcWindowToLocal(12, 16, localZone)} Local)",
                isActive = isLondonNyOverlap,
                description = "Highest global FX, Gold, and US index liquidity. Best window for clean breakouts & trend continuation."
            ),
            OverlapWindowInfo(
                title = "Tokyo / London Overlap",
                utcWindow = "07:00 – 09:00 UTC (${formatUtcWindowToLocal(7, 9, localZone)} Local)",
                isActive = isTokyoLondonOverlap,
                description = "Frankfurt & London open liquidity sweep of Asian session highs/lows."
            )
        )

        val macroWindows = listOf(
            MacroWindowNote(
                title = "London Open Killzone",
                utcWindow = "07:00 – 09:00 UTC",
                detail = "EUR/GBP/UK macro releases & stop hunts around Asian range",
                isNow = utcHour in 7..8
            ),
            MacroWindowNote(
                title = "US Macro & NY Open Window",
                utcWindow = "12:30 – 14:30 UTC",
                detail = "Typical CPI, NFP, GDP, Jobless Claims & NYSE open volatility",
                isNow = (utcHour == 12 && utcMinute >= 30) || utcHour == 13 || (utcHour == 14 && utcMinute <= 30)
            ),
            MacroWindowNote(
                title = "Daily Rollover / Wide Spreads",
                utcWindow = "21:00 – 22:00 UTC",
                detail = "Bank settlement rollover — avoid tight stops on 1m/5m charts",
                isNow = utcHour == 21
            )
        )

        val activeNames = sessions.filter { it.status != SessionStatus.CLOSED }.map { it.regionTag }
        val activeSummary = when {
            isLondonNyOverlap -> "LDN + NYC OVERLAP • PEAK VOLATILITY"
            isTokyoLondonOverlap -> "TYO + LDN OVERLAP • HIGH ACTIVITY"
            activeNames.isNotEmpty() -> "${activeNames.joinToString(" + ")} ACTIVE"
            else -> "OFF-PEAK TRANSITION"
        }

        return SessionSnapshot(
            utcTimeFormatted = utcNow.format(timeFormatter) + " UTC",
            localTimeFormatted = localNow.format(timeFormatter),
            localZoneLabel = localZone.id,
            activeSummaryLabel = activeSummary,
            isOverlapActive = isAnyOverlap,
            sessions = sessions,
            overlaps = overlaps,
            macroWindows = macroWindows
        )
    }

    private fun isHourInWindow(hour: Int, openUtc: Int, closeUtc: Int): Boolean {
        return if (openUtc < closeUtc) {
            hour in openUtc until closeUtc
        } else {
            hour >= openUtc || hour < closeUtc
        }
    }

    private fun buildStatusDetail(
        utcMinutesOfDay: Int,
        openHourUtc: Int,
        closeHourUtc: Int,
        isOpen: Boolean
    ): String {
        val targetHour = if (isOpen) closeHourUtc else openHourUtc
        val targetMinutes = targetHour * 60
        var diff = targetMinutes - utcMinutesOfDay
        if (diff <= 0) diff += 24 * 60
        val h = diff / 60
        val m = diff % 60
        return if (isOpen) {
            "Closes in ${h}h ${m}m"
        } else {
            "Opens in ${h}h ${m}m"
        }
    }

    private fun formatUtcWindowToLocal(openUtc: Int, closeUtc: Int, localZone: ZoneId): String {
        val todayUtc = ZonedDateTime.now(ZoneOffset.UTC).withMinute(0).withSecond(0).withNano(0)
        val startLocal = todayUtc.withHour(openUtc).withZoneSameInstant(localZone)
        val endLocal = todayUtc.withHour(closeUtc).withZoneSameInstant(localZone)
        return "${startLocal.format(shortTimeFormatter)}–${endLocal.format(shortTimeFormatter)}"
    }
}
