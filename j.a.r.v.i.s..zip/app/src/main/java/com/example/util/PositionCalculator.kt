package com.example.util

import com.example.model.InstrumentPreset
import com.example.model.PositionCalcResult
import kotlin.math.max

object PositionCalculator {
    fun calculate(
        accountBalance: Double,
        riskPercent: Double,
        stopLossPipsOrPoints: Double,
        preset: InstrumentPreset,
        customPipValuePerLot: Double? = null
    ): PositionCalcResult? {
        if (accountBalance <= 0.0 || riskPercent <= 0.0 || stopLossPipsOrPoints <= 0.0) {
            return null
        }
        val valuePerLot = (customPipValuePerLot ?: preset.defaultValuePerUnitPerLot).coerceAtLeast(0.01)
        val dollarRisk = accountBalance * (riskPercent / 100.0)
        val rawPositionSize = dollarRisk / (stopLossPipsOrPoints * valuePerLot)

        val roundedSize = when (preset) {
            InstrumentPreset.INDICES_CRYPTO -> (rawPositionSize * 100.0).toLong() / 100.0
            else -> max(0.01, ((rawPositionSize * 100.0).toLong() / 100.0))
        }

        val subDetail = when (preset) {
            InstrumentPreset.FOREX_STANDARD, InstrumentPreset.FOREX_JPY -> {
                val units = (roundedSize * 100_000.0).toLong()
                "%,d currency units".format(units)
            }
            InstrumentPreset.GOLD_XAU -> {
                val ounces = roundedSize * 100.0
                "%.1f troy oz".format(ounces)
            }
            InstrumentPreset.INDICES_CRYPTO -> {
                "1:1 contract / share sizing"
            }
        }

        val riskLevel = when {
            riskPercent <= 1.0 -> "CONSERVATIVE (≤ 1%)"
            riskPercent <= 2.0 -> "MODERATE (1–2%)"
            else -> "AGGRESSIVE (> 2%)"
        }

        return PositionCalcResult(
            dollarRisk = dollarRisk,
            positionSize = roundedSize,
            unitLabel = preset.unitLabel,
            subUnitDetail = subDetail,
            target2RProfit = dollarRisk * 2.0,
            target3RProfit = dollarRisk * 3.0,
            riskLevelLabel = riskLevel
        )
    }
}
