package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val JarvisDarkColorScheme = darkColorScheme(
    primary = NeonCyan,
    onPrimary = Color(0xFF001F26),
    primaryContainer = NeonCyanContainer,
    onPrimaryContainer = NeonCyan,
    secondary = GoodEmerald,
    onSecondary = Color(0xFF002110),
    secondaryContainer = GoodEmeraldContainer,
    onSecondaryContainer = GoodEmerald,
    tertiary = WaitAmber,
    onTertiary = Color(0xFF261900),
    tertiaryContainer = WaitAmberContainer,
    onTertiaryContainer = WaitAmber,
    error = NoCrimson,
    onError = Color(0xFF2D0008),
    errorContainer = NoCrimsonContainer,
    onErrorContainer = NoCrimson,
    background = ObsidianBg,
    onBackground = TextPrimary,
    surface = TerminalSurface,
    onSurface = TextPrimary,
    surfaceVariant = TerminalSurfaceElevated,
    onSurfaceVariant = TextSecondary,
    surfaceContainerLow = TerminalSurface,
    surfaceContainer = TerminalSurfaceElevated,
    surfaceContainerHigh = TerminalSurfaceHigh,
    outline = TerminalBorder,
    outlineVariant = TerminalBorderBright
)

val JarvisShapes = Shapes(
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(26.dp)
)

@Composable
fun JarvisTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = JarvisDarkColorScheme,
        typography = JarvisTypography,
        shapes = JarvisShapes,
        content = content
    )
}
