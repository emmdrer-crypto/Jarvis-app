package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.HourglassBottom
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.ChatMessage
import com.example.model.TradeAnalysisResult
import com.example.model.VerdictType
import com.example.ui.theme.GoodEmerald
import com.example.ui.theme.GoodEmeraldContainer
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonCyanContainer
import com.example.ui.theme.NoCrimson
import com.example.ui.theme.NoCrimsonContainer
import com.example.ui.theme.TerminalBorder
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TerminalSurfaceElevated
import com.example.ui.theme.TerminalSurfaceHigh
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WaitAmber
import com.example.ui.theme.WaitAmberContainer

@Composable
fun TerminalCard(
    modifier: Modifier = Modifier,
    borderColor: Color = TerminalBorder,
    backgroundColor: Color = TerminalSurface,
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = backgroundColor,
        border = BorderStroke(1.dp, borderColor),
        tonalElevation = 2.dp
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            content = content
        )
    }
}

@Composable
fun SessionStatusPill(
    label: String,
    isOverlap: Boolean,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "session_pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.45f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 900),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_alpha"
    )

    val accent = if (isOverlap) GoodEmerald else NeonCyan
    val bg = if (isOverlap) GoodEmeraldContainer else NeonCyanContainer

    Row(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(bg)
            .border(1.dp, accent.copy(alpha = 0.55f), RoundedCornerShape(50))
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(accent.copy(alpha = pulseAlpha))
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = accent,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun VerdictBadge(
    verdict: VerdictType,
    modifier: Modifier = Modifier
) {
    val (fg, bg, icon) = when (verdict) {
        VerdictType.GOOD_SETUP -> Triple(GoodEmerald, GoodEmeraldContainer, Icons.Filled.CheckCircle)
        VerdictType.WAIT -> Triple(WaitAmber, WaitAmberContainer, Icons.Filled.HourglassBottom)
        VerdictType.NO_TRADE -> Triple(NoCrimson, NoCrimsonContainer, Icons.Filled.Cancel)
    }
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(bg)
            .border(1.dp, fg.copy(alpha = 0.65f), RoundedCornerShape(10.dp))
            .padding(horizontal = 10.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = verdict.label,
            tint = fg,
            modifier = Modifier.size(16.dp)
        )
        Text(
            text = verdict.label,
            style = MaterialTheme.typography.labelMedium,
            color = fg,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun VerdictCard(
    result: TradeAnalysisResult,
    modifier: Modifier = Modifier
) {
    val (accent, containerBg, icon) = when (result.verdict) {
        VerdictType.GOOD_SETUP -> Triple(GoodEmerald, GoodEmeraldContainer, Icons.Filled.CheckCircle)
        VerdictType.WAIT -> Triple(WaitAmber, WaitAmberContainer, Icons.Filled.HourglassBottom)
        VerdictType.NO_TRADE -> Triple(NoCrimson, NoCrimsonContainer, Icons.Filled.Cancel)
    }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("verdict_card"),
        shape = RoundedCornerShape(18.dp),
        color = TerminalSurfaceElevated,
        border = BorderStroke(1.5.dp, accent.copy(alpha = 0.75f)),
        tonalElevation = 4.dp
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        Brush.horizontalGradient(
                            listOf(containerBg, TerminalSurfaceHigh)
                        )
                    )
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = result.verdict.label,
                        tint = accent,
                        modifier = Modifier.size(30.dp)
                    )
                    Column {
                        Text(
                            text = result.verdict.label,
                            style = MaterialTheme.typography.headlineSmall,
                            color = accent,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${result.pair} • ${result.timeframe}",
                            style = MaterialTheme.typography.labelMedium,
                            color = TextSecondary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = result.confidenceSummary,
                style = MaterialTheme.typography.bodyLarge,
                color = TextPrimary,
                fontWeight = FontWeight.Medium
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Entry / SL / TP Zones
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ZoneRow(label = "ENTRY ZONE", value = result.entryZone, accent = NeonCyan)
                ZoneRow(label = "STOP-LOSS", value = result.stopLossZone, accent = NoCrimson)
                ZoneRow(label = "TAKE-PROFIT", value = result.takeProfitZone, accent = GoodEmerald)
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "MARKET STRUCTURE",
                style = MaterialTheme.typography.labelMedium,
                color = NeonCyan
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = result.marketStructureNotes,
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )

            if (result.riskWarnings.isNotEmpty()) {
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.WarningAmber,
                        contentDescription = "Risk warnings",
                        tint = WaitAmber,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "RISK WARNINGS",
                        style = MaterialTheme.typography.labelMedium,
                        color = WaitAmber
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    result.riskWarnings.forEach { warning ->
                        Text(
                            text = "• $warning",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextPrimary.copy(alpha = 0.9f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ZoneRow(
    label: String,
    value: String,
    accent: Color
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(TerminalSurface)
            .border(1.dp, TerminalBorder, RoundedCornerShape(10.dp))
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = accent,
            modifier = Modifier.width(92.dp)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            color = TextPrimary,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
fun DisclaimerBanner(modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(TerminalSurface)
            .border(1.dp, TerminalBorder, RoundedCornerShape(12.dp))
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Icon(
            imageVector = Icons.Filled.Info,
            contentDescription = "Disclaimer",
            tint = TextMuted,
            modifier = Modifier.size(16.dp)
        )
        Text(
            text = stringResource(R.string.disclaimer_banner),
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary
        )
    }
}

@Composable
fun PersistentChatPanel(
    messages: List<ChatMessage>,
    chatInput: String,
    isStreaming: Boolean,
    isExpanded: Boolean,
    alwaysExpanded: Boolean,
    onToggleExpand: () -> Unit,
    onInputChange: (String) -> Unit,
    onSend: (String?) -> Unit,
    modifier: Modifier = Modifier
) {
    val listState = rememberLazyListState()
    val effectiveExpanded = alwaysExpanded || isExpanded

    LaunchedEffect(messages.size, messages.lastOrNull()?.text?.length) {
        if (messages.isNotEmpty() && effectiveExpanded) {
            listState.animateScrollToItem(messages.lastIndex)
        }
    }

    val quickPrompts = listOf(
        "Bias on this pair?",
        "Key liquidity levels?",
        "What invalidates this setup?"
    )

    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = if (alwaysExpanded) RoundedCornerShape(18.dp) else RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
        color = TerminalSurfaceElevated,
        border = BorderStroke(1.dp, NeonCyan.copy(alpha = 0.35f)),
        tonalElevation = 6.dp
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Header bar (click to expand/collapse on phones)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .then(
                        if (!alwaysExpanded) {
                            Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .clickable { onToggleExpand() }
                        } else {
                            Modifier
                        }
                    )
                    .padding(horizontal = 4.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Filled.AutoAwesome,
                        contentDescription = "J.A.R.V.I.S. AI",
                        tint = NeonCyan,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = "J.A.R.V.I.S. LIVE CHAT",
                        style = MaterialTheme.typography.titleSmall,
                        color = NeonCyan
                    )
                    if (!effectiveExpanded) {
                        val lastJarvis = messages.lastOrNull { !it.isUser }?.text.orEmpty()
                        if (lastJarvis.isNotBlank()) {
                            Text(
                                text = "• $lastJarvis",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
                if (!alwaysExpanded) {
                    IconButton(
                        onClick = onToggleExpand,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("toggle_chat_expand")
                    ) {
                        Icon(
                            imageVector = if (effectiveExpanded) Icons.Filled.ExpandMore else Icons.Filled.ExpandLess,
                            contentDescription = if (effectiveExpanded) "Collapse chat" else "Expand chat",
                            tint = NeonCyan
                        )
                    }
                }
            }

            AnimatedVisibility(visible = effectiveExpanded) {
                Column {
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyColumn(
                        state = listState,
                        modifier = Modifier
                            .fillMaxWidth()
                            .then(
                                if (alwaysExpanded) {
                                    Modifier.heightIn(min = 240.dp, max = 420.dp)
                                } else {
                                    Modifier.height(220.dp)
                                }
                            )
                            .clip(RoundedCornerShape(12.dp))
                            .background(TerminalSurface)
                            .border(1.dp, TerminalBorder, RoundedCornerShape(12.dp))
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(messages, key = { it.id }) { msg ->
                            ChatBubble(message = msg)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Quick prompt pills
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        quickPrompts.forEach { prompt ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(50))
                                    .background(NeonCyanContainer)
                                    .border(1.dp, NeonCyan.copy(alpha = 0.4f), RoundedCornerShape(50))
                                    .clickable(enabled = !isStreaming) { onSend(prompt) }
                                    .padding(horizontal = 12.dp, vertical = 7.dp)
                            ) {
                                Text(
                                    text = prompt,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = NeonCyan
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Input Row (always visible, large touch targets for tablets & phones)
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = chatInput,
                    onValueChange = onInputChange,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("main_chat_input"),
                    placeholder = {
                        Text(
                            text = stringResource(R.string.chat_placeholder),
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextMuted,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { onSend(null) }),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonCyan,
                        unfocusedBorderColor = TerminalBorder,
                        focusedContainerColor = TerminalSurface,
                        unfocusedContainerColor = TerminalSurface,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        cursorColor = NeonCyan
                    )
                )

                Surface(
                    onClick = { onSend(null) },
                    enabled = !isStreaming && chatInput.isNotBlank(),
                    shape = RoundedCornerShape(14.dp),
                    color = if (!isStreaming && chatInput.isNotBlank()) NeonCyan else TerminalSurfaceHigh,
                    modifier = Modifier
                        .size(54.dp)
                        .testTag("main_chat_send")
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        if (isStreaming) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(22.dp),
                                color = NeonCyan,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Send,
                                contentDescription = "Send message",
                                tint = if (chatInput.isNotBlank()) Color(0xFF001F26) else TextMuted
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ChatBubble(message: ChatMessage) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (message.isUser) Arrangement.End else Arrangement.Start
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .clip(RoundedCornerShape(12.dp))
                .background(if (message.isUser) NeonCyanContainer else TerminalSurfaceElevated)
                .border(
                    width = 1.dp,
                    color = if (message.isUser) NeonCyan.copy(alpha = 0.45f) else TerminalBorder,
                    shape = RoundedCornerShape(12.dp)
                )
                .padding(horizontal = 12.dp, vertical = 9.dp)
        ) {
            Column {
                Text(
                    text = if (message.isUser) "TRADER" else "J.A.R.V.I.S.",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (message.isUser) NeonCyan else GoodEmerald
                )
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = if (message.text.isBlank() && message.isStreaming) "Analyzing…" else message.text,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextPrimary
                )
            }
        }
    }
}
