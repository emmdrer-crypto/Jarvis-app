package com.example.ui.screens

import android.graphics.Bitmap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Cast
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.model.ChatMessage
import com.example.model.ScanUiState
import com.example.model.TimeframeOption
import com.example.overlay.ScreenShareUiState
import com.example.ui.ScannerScreenState
import com.example.ui.components.DisclaimerBanner
import com.example.ui.components.PersistentChatPanel
import com.example.ui.components.SessionStatusPill
import com.example.ui.components.TerminalCard
import com.example.ui.components.VerdictCard
import com.example.ui.theme.GoodEmerald
import com.example.ui.theme.GoodEmeraldContainer
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonCyanContainer
import com.example.ui.theme.NoCrimson
import com.example.ui.theme.NoCrimsonContainer
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.TerminalBorder
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TerminalSurfaceElevated
import com.example.ui.theme.TerminalSurfaceHigh
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WaitAmber
import com.example.ui.theme.WaitAmberContainer
import com.example.util.SessionSnapshot

private val QuickTickers = listOf("EUR/USD", "GBP/USD", "XAU/USD", "BTC/USD", "NAS100", "AAPL", "NVDA")

@Composable
fun ScannerScreen(
    scannerState: ScannerScreenState,
    sessionSnapshot: SessionSnapshot,
    screenShareState: ScreenShareUiState,
    chatMessages: List<ChatMessage>,
    chatInput: String,
    isChatStreaming: Boolean,
    onPairChange: (String) -> Unit,
    onTimeframeSelect: (TimeframeOption) -> Unit,
    onToggleHigherTimeframe: (Boolean) -> Unit,
    onToggleMinRiskReward: (Boolean) -> Unit,
    onToggleClearSlTp: (Boolean) -> Unit,
    onToggleNoNews: (Boolean) -> Unit,
    onTraderNoteChange: (String) -> Unit,
    onChartPicked: (android.net.Uri) -> Unit,
    onClearChart: () -> Unit,
    onScanTrade: () -> Unit,
    onStartScreenShare: () -> Unit,
    onStopScreenShare: () -> Unit,
    onChatInputChange: (String) -> Unit,
    onSendChat: (String?) -> Unit,
    modifier: Modifier = Modifier
) {
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
        onResult = { uri ->
            if (uri != null) {
                onChartPicked(uri)
            }
        }
    )

    var previewBitmapDialog by remember { mutableStateOf<Bitmap?>(null) }
    var isPhoneChatExpanded by remember { mutableStateOf(false) }

    if (previewBitmapDialog != null) {
        Dialog(onDismissRequest = { previewBitmapDialog = null }) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = TerminalSurfaceElevated,
                border = BorderStroke(1.dp, NeonCyan)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${scannerState.pairInput} • ${scannerState.timeframe.label}",
                            style = MaterialTheme.typography.titleSmall,
                            color = NeonCyan
                        )
                        IconButton(onClick = { previewBitmapDialog = null }) {
                            Icon(
                                imageVector = Icons.Filled.Close,
                                contentDescription = "Close preview",
                                tint = TextPrimary
                            )
                        }
                    }
                    previewBitmapDialog?.let { bmp ->
                        Image(
                            bitmap = bmp.asImageBitmap(),
                            contentDescription = "Full chart screenshot preview",
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 460.dp)
                                .clip(RoundedCornerShape(12.dp)),
                            contentScale = ContentScale.Fit
                        )
                    }
                }
            }
        }
    }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBg)
    ) {
        val isExpandedTablet = maxWidth >= 840.dp

        if (isExpandedTablet) {
            // Two-Pane Tablet Layout: Left = Controls & Scan, Right = Verdict & Live Chat
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .weight(1.1f)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    ScannerHeroHeader(
                        sessionSnapshot = sessionSnapshot,
                        screenShareState = screenShareState,
                        onStartScreenShare = onStartScreenShare,
                        onStopScreenShare = onStopScreenShare
                    )
                    PairAndTimeframeSelector(
                        pairInput = scannerState.pairInput,
                        selectedTimeframe = scannerState.timeframe,
                        onPairChange = onPairChange,
                        onTimeframeSelect = onTimeframeSelect
                    )
                    ChartUploadSection(
                        chartBitmap = scannerState.chartBitmap,
                        onUploadClick = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        onPreviewClick = { previewBitmapDialog = scannerState.chartBitmap },
                        onClearClick = onClearChart
                    )
                    DisciplineChecklistCard(
                        scannerState = scannerState,
                        onToggleHigherTimeframe = onToggleHigherTimeframe,
                        onToggleMinRiskReward = onToggleMinRiskReward,
                        onToggleClearSlTp = onToggleClearSlTp,
                        onToggleNoNews = onToggleNoNews,
                        onTraderNoteChange = onTraderNoteChange
                    )
                    ScanActionButton(
                        isScanning = scannerState.scanUiState is ScanUiState.Scanning,
                        onClick = onScanTrade
                    )
                    DisclaimerBanner()
                }

                Column(
                    modifier = Modifier
                        .weight(0.95f)
                        .fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .verticalScroll(rememberScrollState())
                    ) {
                        VerdictOutputSection(
                            scanUiState = scannerState.scanUiState,
                            screenShareState = screenShareState
                        )
                    }
                    PersistentChatPanel(
                        messages = chatMessages,
                        chatInput = chatInput,
                        isStreaming = isChatStreaming,
                        isExpanded = true,
                        alwaysExpanded = true,
                        onToggleExpand = {},
                        onInputChange = onChatInputChange,
                        onSend = onSendChat
                    )
                }
            }
        } else {
            // Handheld / Medium Vertical Layout with Persistent Bottom Chat Dock
            Column(modifier = Modifier.fillMaxSize()) {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    ScannerHeroHeader(
                        sessionSnapshot = sessionSnapshot,
                        screenShareState = screenShareState,
                        onStartScreenShare = onStartScreenShare,
                        onStopScreenShare = onStopScreenShare
                    )
                    PairAndTimeframeSelector(
                        pairInput = scannerState.pairInput,
                        selectedTimeframe = scannerState.timeframe,
                        onPairChange = onPairChange,
                        onTimeframeSelect = onTimeframeSelect
                    )
                    ChartUploadSection(
                        chartBitmap = scannerState.chartBitmap,
                        onUploadClick = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        onPreviewClick = { previewBitmapDialog = scannerState.chartBitmap },
                        onClearClick = onClearChart
                    )
                    DisciplineChecklistCard(
                        scannerState = scannerState,
                        onToggleHigherTimeframe = onToggleHigherTimeframe,
                        onToggleMinRiskReward = onToggleMinRiskReward,
                        onToggleClearSlTp = onToggleClearSlTp,
                        onToggleNoNews = onToggleNoNews,
                        onTraderNoteChange = onTraderNoteChange
                    )
                    ScanActionButton(
                        isScanning = scannerState.scanUiState is ScanUiState.Scanning,
                        onClick = onScanTrade
                    )
                    VerdictOutputSection(
                        scanUiState = scannerState.scanUiState,
                        screenShareState = screenShareState
                    )
                    DisclaimerBanner()
                    Spacer(modifier = Modifier.height(6.dp))
                }

                PersistentChatPanel(
                    messages = chatMessages,
                    chatInput = chatInput,
                    isStreaming = isChatStreaming,
                    isExpanded = isPhoneChatExpanded,
                    alwaysExpanded = false,
                    onToggleExpand = { isPhoneChatExpanded = !isPhoneChatExpanded },
                    onInputChange = onChatInputChange,
                    onSend = { prompt ->
                        isPhoneChatExpanded = true
                        onSendChat(prompt)
                    }
                )
            }
        }
    }
}

@Composable
private fun ScannerHeroHeader(
    sessionSnapshot: SessionSnapshot,
    screenShareState: ScreenShareUiState,
    onStartScreenShare: () -> Unit,
    onStopScreenShare: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(TerminalSurface)
            .border(1.dp, TerminalBorder, RoundedCornerShape(18.dp))
    ) {
        Image(
            painter = painterResource(id = R.drawable.img_jarvis_terminal_banner_1795692786203),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .matchParentSize()
                .alpha(0.32f)
        )
        Box(
            modifier = Modifier
                .matchParentSize()
                .background(
                    Brush.horizontalGradient(
                        listOf(ObsidianBg.copy(alpha = 0.9f), TerminalSurface.copy(alpha = 0.6f))
                    )
                )
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "J.A.R.V.I.S.",
                        style = MaterialTheme.typography.headlineMedium,
                        color = NeonCyan
                    )
                    Text(
                        text = "AI MARKET SCANNER & TRADE COPILOT",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                }
                SessionStatusPill(
                    label = sessionSnapshot.activeSummaryLabel,
                    isOverlap = sessionSnapshot.isOverlapActive
                )
            }

            // Live Screen Share Mode Button
            if (screenShareState.isSharing) {
                Button(
                    onClick = onStopScreenShare,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = NoCrimson,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("stop_screen_share_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.StopCircle,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Overlay Live Over Charts • Stop Sharing",
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            } else {
                OutlinedButton(
                    onClick = onStartScreenShare,
                    border = BorderStroke(1.5.dp, NeonCyan),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = NeonCyanContainer.copy(alpha = 0.65f),
                        contentColor = NeonCyan
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("share_screen_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Cast,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Share Screen • Live Overlay on TradingView / MT5",
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }
        }
    }
}

@Composable
private fun PairAndTimeframeSelector(
    pairInput: String,
    selectedTimeframe: TimeframeOption,
    onPairChange: (String) -> Unit,
    onTimeframeSelect: (TimeframeOption) -> Unit
) {
    TerminalCard {
        Text(
            text = "ASSET & TIMEFRAME",
            style = MaterialTheme.typography.labelMedium,
            color = NeonCyan
        )
        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = pairInput,
            onValueChange = onPairChange,
            label = { Text("Pair / Crypto / Stock Ticker") },
            placeholder = { Text("e.g. EUR/USD, BTC/USD, NVDA") },
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("pair_input"),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = NeonCyan,
                unfocusedBorderColor = TerminalBorder,
                focusedContainerColor = TerminalSurfaceElevated,
                unfocusedContainerColor = TerminalSurfaceElevated,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary,
                focusedLabelColor = NeonCyan,
                unfocusedLabelColor = TextSecondary
            )
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            QuickTickers.forEach { ticker ->
                val isSelected = pairInput.equals(ticker, ignoreCase = true)
                Box(
                    modifier = Modifier
                        .heightIn(min = 40.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isSelected) NeonCyanContainer else TerminalSurfaceElevated)
                        .border(
                            1.dp,
                            if (isSelected) NeonCyan else TerminalBorder,
                            RoundedCornerShape(10.dp)
                        )
                        .clickable { onPairChange(ticker) }
                        .padding(horizontal = 12.dp, vertical = 9.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = ticker,
                        style = MaterialTheme.typography.labelMedium,
                        color = if (isSelected) NeonCyan else TextSecondary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TimeframeOption.entries.forEach { tf ->
                val selected = tf == selectedTimeframe
                Box(
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .height(48.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (selected) NeonCyan else TerminalSurfaceElevated)
                        .border(
                            1.dp,
                            if (selected) NeonCyan else TerminalBorder,
                            RoundedCornerShape(12.dp)
                        )
                        .clickable { onTimeframeSelect(tf) }
                        .testTag("timeframe_${tf.label}")
                        .padding(horizontal = 16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = tf.label,
                        style = MaterialTheme.typography.labelLarge,
                        color = if (selected) Color(0xFF001F26) else TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun ChartUploadSection(
    chartBitmap: Bitmap?,
    onUploadClick: () -> Unit,
    onPreviewClick: () -> Unit,
    onClearClick: () -> Unit
) {
    TerminalCard {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "CHART SCREENSHOT",
                style = MaterialTheme.typography.labelMedium,
                color = NeonCyan
            )
            if (chartBitmap != null) {
                TextButton(
                    onClick = onClearClick,
                    modifier = Modifier.testTag("clear_chart_button")
                ) {
                    Text(
                        text = stringResource(R.string.action_clear_chart),
                        color = NoCrimson,
                        style = MaterialTheme.typography.labelMedium
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        if (chartBitmap != null) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(190.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .border(1.dp, NeonCyan.copy(alpha = 0.55f), RoundedCornerShape(14.dp))
                    .clickable { onPreviewClick() }
            ) {
                Image(
                    bitmap = chartBitmap.asImageBitmap(),
                    contentDescription = "Uploaded trading chart thumbnail",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(10.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(ObsidianBg.copy(alpha = 0.8f))
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = "Tap to expand",
                        style = MaterialTheme.typography.labelSmall,
                        color = NeonCyan
                    )
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
            OutlinedButton(
                onClick = onUploadClick,
                border = BorderStroke(1.dp, TerminalBorder),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("upload_chart_button")
            ) {
                Icon(
                    imageVector = Icons.Filled.AddPhotoAlternate,
                    contentDescription = null,
                    tint = NeonCyan
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = stringResource(R.string.action_replace_chart),
                    color = TextPrimary,
                    style = MaterialTheme.typography.labelLarge
                )
            }
        } else {
            OutlinedButton(
                onClick = onUploadClick,
                border = BorderStroke(1.dp, NeonCyan.copy(alpha = 0.5f)),
                colors = ButtonDefaults.outlinedButtonColors(
                    containerColor = TerminalSurfaceElevated,
                    contentColor = NeonCyan
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(62.dp)
                    .testTag("upload_chart_button")
            ) {
                Icon(
                    imageVector = Icons.Filled.AddPhotoAlternate,
                    contentDescription = null,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = stringResource(R.string.action_upload_chart),
                    style = MaterialTheme.typography.titleSmall
                )
            }
        }
    }
}

@Composable
private fun DisciplineChecklistCard(
    scannerState: ScannerScreenState,
    onToggleHigherTimeframe: (Boolean) -> Unit,
    onToggleMinRiskReward: (Boolean) -> Unit,
    onToggleClearSlTp: (Boolean) -> Unit,
    onToggleNoNews: (Boolean) -> Unit,
    onTraderNoteChange: (String) -> Unit
) {
    val checklist = scannerState.checklist
    val count = checklist.completedCount
    val (scoreColor, scoreBg) = when (count) {
        4 -> GoodEmerald to GoodEmeraldContainer
        2, 3 -> WaitAmber to WaitAmberContainer
        else -> NoCrimson to NoCrimsonContainer
    }

    TerminalCard {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "PRE-TRADE DISCIPLINE CHECKLIST",
                style = MaterialTheme.typography.labelMedium,
                color = NeonCyan
            )
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(scoreBg)
                    .border(1.dp, scoreColor.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "$count/4 MET",
                    style = MaterialTheme.typography.labelSmall,
                    color = scoreColor
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        ChecklistToggleRow(
            label = "Higher timeframe trend confirmed",
            checked = checklist.higherTimeframeConfirmed,
            onCheckedChange = onToggleHigherTimeframe,
            tag = "switch_htf"
        )
        ChecklistToggleRow(
            label = "At least 1:2 Risk-to-Reward ratio",
            checked = checklist.minRiskRewardMet,
            onCheckedChange = onToggleMinRiskReward,
            tag = "switch_rr"
        )
        ChecklistToggleRow(
            label = "Clear Stop-Loss & Take-Profit levels set",
            checked = checklist.clearSlTpSet,
            onCheckedChange = onToggleClearSlTp,
            tag = "switch_sltp"
        )
        ChecklistToggleRow(
            label = "No high-impact news in the next 30 minutes",
            checked = checklist.noHighImpactNews,
            onCheckedChange = onToggleNoNews,
            tag = "switch_news"
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = scannerState.traderNote,
            onValueChange = onTraderNoteChange,
            label = { Text("Setup Notes (Optional)") },
            placeholder = { Text("e.g. Swept London low, 15m MSS bullish") },
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("trader_note_input"),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = NeonCyan,
                unfocusedBorderColor = TerminalBorder,
                focusedContainerColor = TerminalSurfaceElevated,
                unfocusedContainerColor = TerminalSurfaceElevated,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary,
                focusedLabelColor = NeonCyan,
                unfocusedLabelColor = TextSecondary
            )
        )
    }
}

@Composable
private fun ChecklistToggleRow(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    tag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 56.dp)
            .clip(RoundedCornerShape(12.dp))
            .clickable { onCheckedChange(!checked) }
            .padding(horizontal = 4.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = if (checked) TextPrimary else TextSecondary,
            modifier = Modifier
                .weight(1f)
                .padding(end = 12.dp)
        )
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            modifier = Modifier.testTag(tag),
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color(0xFF002110),
                checkedTrackColor = GoodEmerald,
                uncheckedThumbColor = TextSecondary,
                uncheckedTrackColor = TerminalSurfaceHigh,
                uncheckedBorderColor = TerminalBorder
            )
        )
    }
}

@Composable
private fun ScanActionButton(
    isScanning: Boolean,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        enabled = !isScanning,
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = NeonCyan,
            contentColor = Color(0xFF001F26),
            disabledContainerColor = NeonCyanContainer,
            disabledContentColor = NeonCyan
        ),
        modifier = Modifier
            .fillMaxWidth()
            .height(60.dp)
            .testTag("scan_trade_button")
    ) {
        if (isScanning) {
            CircularProgressIndicator(
                modifier = Modifier.size(22.dp),
                color = NeonCyan,
                strokeWidth = 2.5.dp
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = "J.A.R.V.I.S. SCANNING SETUP…",
                style = MaterialTheme.typography.titleSmall
            )
        } else {
            Icon(
                imageVector = Icons.Filled.Radar,
                contentDescription = null,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = stringResource(R.string.action_scan_trade),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun VerdictOutputSection(
    scanUiState: ScanUiState,
    screenShareState: ScreenShareUiState
) {
    when (scanUiState) {
        is ScanUiState.Idle -> {
            val snap = screenShareState.lastSnapResult
            if (snap != null) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "LATEST OVERLAY SNAP RESULT",
                        style = MaterialTheme.typography.labelMedium,
                        color = NeonCyan
                    )
                    VerdictCard(result = snap)
                }
            } else {
                TerminalCard(borderColor = TerminalBorder) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Psychology,
                            contentDescription = null,
                            tint = NeonCyan,
                            modifier = Modifier.size(32.dp)
                        )
                        Column {
                            Text(
                                text = "Awaiting Setup Scan",
                                style = MaterialTheme.typography.titleMedium,
                                color = TextPrimary
                            )
                            Text(
                                text = "Upload a chart screenshot or verify your 4 rules, then tap \"Scan Trade — GOOD or NO?\".",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                    }
                }
            }
        }
        is ScanUiState.Scanning -> {
            TerminalCard(borderColor = NeonCyan.copy(alpha = 0.6f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(26.dp),
                        color = NeonCyan,
                        strokeWidth = 2.5.dp
                    )
                    Column {
                        Text(
                            text = "Analyzing Market Structure & Risk…",
                            style = MaterialTheme.typography.titleMedium,
                            color = NeonCyan
                        )
                        Text(
                            text = "Evaluating price action, R:R alignment, and session liquidity.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                }
            }
        }
        is ScanUiState.Success -> {
            VerdictCard(result = scanUiState.result)
        }
        is ScanUiState.Error -> {
            TerminalCard(
                borderColor = NoCrimson.copy(alpha = 0.7f),
                backgroundColor = NoCrimsonContainer.copy(alpha = 0.45f)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.ErrorOutline,
                        contentDescription = "Error",
                        tint = NoCrimson,
                        modifier = Modifier.size(24.dp)
                    )
                    Column {
                        Text(
                            text = "Scan Failed",
                            style = MaterialTheme.typography.titleSmall,
                            color = NoCrimson
                        )
                        Text(
                            text = scanUiState.message,
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextPrimary
                        )
                    }
                }
            }
        }
    }
}
