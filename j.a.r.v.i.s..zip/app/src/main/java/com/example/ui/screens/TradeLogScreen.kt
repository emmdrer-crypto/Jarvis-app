package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.TradeScanEntity
import com.example.model.TradeOutcome
import com.example.model.VerdictType
import com.example.ui.LogFilter
import com.example.ui.components.TerminalCard
import com.example.ui.components.VerdictBadge
import com.example.ui.theme.GoodEmerald
import com.example.ui.theme.GoodEmeraldContainer
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonCyanContainer
import com.example.ui.theme.NoCrimson
import com.example.ui.theme.NoCrimsonContainer
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.TerminalBorder
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TerminalSurfaceElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WaitAmber
import com.example.ui.theme.WaitAmberContainer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun TradeLogScreen(
    allScans: List<TradeScanEntity>,
    filteredScans: List<TradeScanEntity>,
    selectedFilter: LogFilter,
    onSelectFilter: (LogFilter) -> Unit,
    onUpdateOutcome: (Long, TradeOutcome) -> Unit,
    onDeleteScan: (Long) -> Unit,
    onClearAll: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showClearConfirm by remember { mutableStateOf(false) }

    if (showClearConfirm) {
        AlertDialog(
            onDismissRequest = { showClearConfirm = false },
            containerColor = TerminalSurfaceElevated,
            title = { Text("Clear Trade Log?", color = TextPrimary) },
            text = {
                Text(
                    "This will permanently delete all locally saved J.A.R.V.I.S. scan history.",
                    color = TextSecondary
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        onClearAll()
                        showClearConfirm = false
                    }
                ) {
                    Text("Delete All", color = NoCrimson)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearConfirm = false }) {
                    Text("Cancel", color = NeonCyan)
                }
            }
        )
    }

    val totalCount = allScans.size
    val goodCount = allScans.count { it.verdict == VerdictType.GOOD_SETUP.name }
    val disciplinedCount = allScans.count { it.rulesMetCount == 4 }
    val adherencePct = if (totalCount > 0) (disciplinedCount * 100) / totalCount else 0

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBg)
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        // Header + Clear action
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "TRADE LOG & DISCIPLINE",
                    style = MaterialTheme.typography.titleMedium,
                    color = NeonCyan
                )
                Text(
                    text = "Local scan history & rule adherence tracker",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
            if (allScans.isNotEmpty()) {
                TextButton(
                    onClick = { showClearConfirm = true },
                    modifier = Modifier.testTag("clear_all_logs_button")
                ) {
                    Text("Clear All", color = NoCrimson, style = MaterialTheme.typography.labelMedium)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Summary KPI strip
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            LogKpiTile(
                label = "TOTAL SCANS",
                value = totalCount.toString(),
                accent = NeonCyan,
                modifier = Modifier.weight(1f)
            )
            LogKpiTile(
                label = "GOOD SETUPS",
                value = goodCount.toString(),
                accent = GoodEmerald,
                modifier = Modifier.weight(1f)
            )
            LogKpiTile(
                label = "4/4 RULE RATE",
                value = "$adherencePct%",
                accent = if (adherencePct >= 75) GoodEmerald else WaitAmber,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Filter Chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            LogFilter.entries.forEach { filter ->
                val selected = filter == selectedFilter
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (selected) NeonCyanContainer else TerminalSurface)
                        .border(
                            1.dp,
                            if (selected) NeonCyan else TerminalBorder,
                            RoundedCornerShape(10.dp)
                        )
                        .clickable { onSelectFilter(filter) }
                        .padding(horizontal = 14.dp, vertical = 9.dp)
                ) {
                    Text(
                        text = filter.label,
                        style = MaterialTheme.typography.labelMedium,
                        color = if (selected) NeonCyan else TextSecondary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (filteredScans.isEmpty()) {
            TerminalCard(modifier = Modifier.padding(top = 8.dp)) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.History,
                        contentDescription = null,
                        tint = NeonCyan.copy(alpha = 0.7f),
                        modifier = Modifier.size(44.dp)
                    )
                    Text(
                        text = if (allScans.isEmpty()) "No Scans Logged Yet" else "No Scans Match Filter",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary
                    )
                    Text(
                        text = if (allScans.isEmpty()) {
                            "Every \"Scan Trade — GOOD or NO?\" and overlay \"Snap & Check\" scan is automatically saved here for review."
                        } else {
                            "Switch filter above to view your other saved setups."
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredScans, key = { it.id }) { scan ->
                    TradeLogItemCard(
                        scan = scan,
                        onUpdateOutcome = { outcome -> onUpdateOutcome(scan.id, outcome) },
                        onDelete = { onDeleteScan(scan.id) }
                    )
                }
            }
        }
    }
}

@Composable
private fun LogKpiTile(
    label: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(TerminalSurface)
            .border(1.dp, TerminalBorder, RoundedCornerShape(12.dp))
            .padding(10.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = TextMuted
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.titleLarge,
            color = accent,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun TradeLogItemCard(
    scan: TradeScanEntity,
    onUpdateOutcome: (TradeOutcome) -> Unit,
    onDelete: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    val verdict = VerdictType.fromRaw(scan.verdict)
    val dateFormat = remember { SimpleDateFormat("MMM dd • HH:mm", Locale.getDefault()) }
    val formattedTime = remember(scan.timestamp) { dateFormat.format(Date(scan.timestamp)) }

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = TerminalSurface,
        border = BorderStroke(1.dp, TerminalBorder),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { expanded = !expanded }
            .testTag("trade_log_item_${scan.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = scan.pair,
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = scan.timeframe,
                            style = MaterialTheme.typography.labelMedium,
                            color = NeonCyan
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(TerminalSurfaceElevated)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = if (scan.source == "SCREEN_SNAP") "SNAP" else "SCANNER",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondary
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = "$formattedTime  •  ${scan.rulesMetCount}/4 Rules Met",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (scan.rulesMetCount == 4) GoodEmerald else WaitAmber
                    )
                }

                VerdictBadge(verdict = verdict)

                Icon(
                    imageVector = if (expanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                    contentDescription = if (expanded) "Collapse" else "Expand",
                    tint = TextSecondary,
                    modifier = Modifier.padding(start = 6.dp)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = scan.confidenceSummary,
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )

            AnimatedVisibility(visible = expanded) {
                Column(modifier = Modifier.padding(top = 12.dp)) {
                    // Rule Pills
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        RuleTag("HTF Trend", scan.higherTimeframeConfirmed)
                        RuleTag("1:2+ R:R", scan.minRiskRewardMet)
                        RuleTag("SL/TP Set", scan.clearSlTpSet)
                        RuleTag("No News 30m", scan.noHighImpactNews)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Entry: ${scan.entryZone}\nSL: ${scan.stopLossZone}\nTP: ${scan.takeProfitZone}",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextPrimary
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = scan.marketStructureNotes,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )

                    if (scan.riskWarnings.isNotBlank()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Warnings:\n${scan.riskWarnings}",
                            style = MaterialTheme.typography.bodySmall,
                            color = WaitAmber
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "LOG OUTCOME",
                        style = MaterialTheme.typography.labelSmall,
                        color = NeonCyan
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier
                                .weight(1f)
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            TradeOutcome.entries.forEach { outcome ->
                                val active = scan.outcome == outcome.name
                                val (fg, bg) = when {
                                    active && outcome == TradeOutcome.TOOK_WIN -> GoodEmerald to GoodEmeraldContainer
                                    active && outcome == TradeOutcome.TOOK_LOSS -> NoCrimson to NoCrimsonContainer
                                    active && outcome == TradeOutcome.TOOK_BE -> WaitAmber to WaitAmberContainer
                                    active -> NeonCyan to NeonCyanContainer
                                    else -> TextSecondary to TerminalSurfaceElevated
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(bg)
                                        .border(
                                            1.dp,
                                            if (active) fg else TerminalBorder,
                                            RoundedCornerShape(8.dp)
                                        )
                                        .clickable { onUpdateOutcome(outcome) }
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = outcome.label,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = fg
                                    )
                                }
                            }
                        }

                        IconButton(
                            onClick = onDelete,
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("delete_scan_${scan.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.DeleteOutline,
                                contentDescription = "Delete log entry",
                                tint = NoCrimson
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RuleTag(label: String, met: Boolean) {
    val fg = if (met) GoodEmerald else NoCrimson
    val bg = if (met) GoodEmeraldContainer else NoCrimsonContainer
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bg)
            .border(1.dp, fg.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(
            text = "${if (met) "✓" else "✕"} $label",
            style = MaterialTheme.typography.labelSmall,
            color = fg
        )
    }
}
