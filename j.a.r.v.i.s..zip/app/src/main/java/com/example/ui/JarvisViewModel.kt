package com.example.ui

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.JarvisAiRepository
import com.example.data.TradeLogRepository
import com.example.data.local.JarvisDatabase
import com.example.data.local.TradeScanEntity
import com.example.model.ChatMessage
import com.example.model.DisciplineChecklist
import com.example.model.InstrumentPreset
import com.example.model.PositionCalcResult
import com.example.model.ScanUiState
import com.example.model.TimeframeOption
import com.example.model.TradeOutcome
import com.example.model.VerdictType
import com.example.overlay.ScreenShareStateHolder
import com.example.overlay.ScreenShareUiState
import com.example.util.PositionCalculator
import com.example.util.SessionSnapshot
import com.example.util.TradingSessions
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

private const val TAG = "JarvisViewModel"

enum class LogFilter(val label: String) {
    ALL("All"),
    GOOD("GOOD"),
    WAIT("WAIT"),
    NO("NO TRADE"),
    DISCIPLINED("4/4 Rules")
}

data class ScannerScreenState(
    val pairInput: String = "EUR/USD",
    val timeframe: TimeframeOption = TimeframeOption.M15,
    val chartUri: Uri? = null,
    val chartBitmap: Bitmap? = null,
    val checklist: DisciplineChecklist = DisciplineChecklist(),
    val traderNote: String = "",
    val scanUiState: ScanUiState = ScanUiState.Idle
)

data class CalculatorState(
    val balanceText: String = "10000",
    val riskPercentText: String = "1.0",
    val stopLossText: String = "20",
    val preset: InstrumentPreset = InstrumentPreset.FOREX_STANDARD,
    val customPipValueText: String = "",
    val result: PositionCalcResult? = PositionCalculator.calculate(
        accountBalance = 10000.0,
        riskPercent = 1.0,
        stopLossPipsOrPoints = 20.0,
        preset = InstrumentPreset.FOREX_STANDARD
    )
)

class JarvisViewModel(application: Application) : AndroidViewModel(application) {

    private val aiRepository = JarvisAiRepository()
    private val tradeLogRepository = TradeLogRepository(
        JarvisDatabase.getInstance(application.applicationContext).tradeScanDao()
    )

    private val _scannerState = MutableStateFlow(ScannerScreenState())
    val scannerState: StateFlow<ScannerScreenState> = _scannerState.asStateFlow()

    private val _chatMessages = MutableStateFlow(
        listOf(
            ChatMessage(
                id = "welcome",
                isUser = false,
                text = "J.A.R.V.I.S. online. Select your pair and timeframe, upload a chart or launch Screen Share, and ask me anything about market structure or risk."
            )
        )
    )
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _chatInput = MutableStateFlow("")
    val chatInput: StateFlow<String> = _chatInput.asStateFlow()

    private val _isChatStreaming = MutableStateFlow(false)
    val isChatStreaming: StateFlow<Boolean> = _isChatStreaming.asStateFlow()

    private val _chatError = MutableStateFlow<String?>(null)
    val chatError: StateFlow<String?> = _chatError.asStateFlow()

    private val _calculatorState = MutableStateFlow(CalculatorState())
    val calculatorState: StateFlow<CalculatorState> = _calculatorState.asStateFlow()

    private val _sessionSnapshot = MutableStateFlow(TradingSessions.currentSnapshot())
    val sessionSnapshot: StateFlow<SessionSnapshot> = _sessionSnapshot.asStateFlow()

    private val _logFilter = MutableStateFlow(LogFilter.ALL)
    val logFilter: StateFlow<LogFilter> = _logFilter.asStateFlow()

    val screenShareState: StateFlow<ScreenShareUiState> = ScreenShareStateHolder.state

    val allScans: StateFlow<List<TradeScanEntity>> = tradeLogRepository.allScans
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val filteredScans: StateFlow<List<TradeScanEntity>> = combine(allScans, _logFilter) { scans, filter ->
        when (filter) {
            LogFilter.ALL -> scans
            LogFilter.GOOD -> scans.filter { it.verdict == VerdictType.GOOD_SETUP.name }
            LogFilter.WAIT -> scans.filter { it.verdict == VerdictType.WAIT.name }
            LogFilter.NO -> scans.filter { it.verdict == VerdictType.NO_TRADE.name }
            LogFilter.DISCIPLINED -> scans.filter { it.rulesMetCount == 4 }
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    init {
        startSessionClock()
        syncOverlayContext()
    }

    private fun startSessionClock() {
        viewModelScope.launch {
            while (true) {
                _sessionSnapshot.value = TradingSessions.currentSnapshot()
                delay(1000L)
            }
        }
    }

    private fun syncOverlayContext() {
        val s = _scannerState.value
        ScreenShareStateHolder.updateScannerContext(
            pair = s.pairInput,
            timeframe = s.timeframe.label,
            checklist = s.checklist
        )
    }

    fun updatePair(pair: String) {
        _scannerState.update { it.copy(pairInput = pair.uppercase()) }
        syncOverlayContext()
    }

    fun selectTimeframe(tf: TimeframeOption) {
        _scannerState.update { it.copy(timeframe = tf) }
        syncOverlayContext()
    }

    fun updateTraderNote(note: String) {
        _scannerState.update { it.copy(traderNote = note) }
    }

    fun toggleHigherTimeframe(checked: Boolean) {
        _scannerState.update {
            it.copy(checklist = it.checklist.copy(higherTimeframeConfirmed = checked))
        }
        syncOverlayContext()
    }

    fun toggleMinRiskReward(checked: Boolean) {
        _scannerState.update {
            it.copy(checklist = it.checklist.copy(minRiskRewardMet = checked))
        }
        syncOverlayContext()
    }

    fun toggleClearSlTp(checked: Boolean) {
        _scannerState.update {
            it.copy(checklist = it.checklist.copy(clearSlTpSet = checked))
        }
        syncOverlayContext()
    }

    fun toggleNoHighImpactNews(checked: Boolean) {
        _scannerState.update {
            it.copy(checklist = it.checklist.copy(noHighImpactNews = checked))
        }
        syncOverlayContext()
    }

    fun onChartSelected(uri: Uri) {
        viewModelScope.launch {
            val bitmap = withContext(Dispatchers.IO) { decodeBitmapFromUri(uri) }
            if (bitmap != null) {
                _scannerState.update { it.copy(chartUri = uri, chartBitmap = bitmap) }
            } else {
                _scannerState.update {
                    it.copy(
                        scanUiState = ScanUiState.Error("Could not decode the selected chart image.")
                    )
                }
            }
        }
    }

    fun clearChart() {
        _scannerState.update { it.copy(chartUri = null, chartBitmap = null) }
    }

    fun scanTrade() {
        val current = _scannerState.value
        if (current.scanUiState is ScanUiState.Scanning) return

        val cleanPair = current.pairInput.trim().ifBlank { "EUR/USD" }
        _scannerState.update { it.copy(pairInput = cleanPair, scanUiState = ScanUiState.Scanning) }

        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) {
                aiRepository.analyzeTradeSetup(
                    pair = cleanPair,
                    timeframe = current.timeframe.label,
                    checklist = current.checklist,
                    sessionSummary = _sessionSnapshot.value.activeSummaryLabel,
                    chartBitmap = current.chartBitmap,
                    additionalContext = current.traderNote
                )
            }

            result.fold(
                onSuccess = { analysis ->
                    _scannerState.update { it.copy(scanUiState = ScanUiState.Success(analysis)) }
                    withContext(Dispatchers.IO) {
                        tradeLogRepository.saveScan(
                            result = analysis,
                            checklist = current.checklist,
                            source = "SCANNER"
                        )
                    }
                },
                onFailure = { error ->
                    _scannerState.update {
                        it.copy(
                            scanUiState = ScanUiState.Error(
                                error.localizedMessage ?: "Unable to analyze setup."
                            )
                        )
                    }
                }
            )
        }
    }

    fun updateChatInput(text: String) {
        _chatInput.value = text
    }

    fun sendChatMessage(overridePrompt: String? = null) {
        val textToSend = (overridePrompt ?: _chatInput.value).trim()
        if (textToSend.isBlank() || _isChatStreaming.value) return

        if (overridePrompt == null) {
            _chatInput.value = ""
        }
        _chatError.value = null

        val userMsg = ChatMessage(
            id = UUID.randomUUID().toString(),
            isUser = true,
            text = textToSend
        )
        val assistantMsgId = UUID.randomUUID().toString()
        val placeholderMsg = ChatMessage(
            id = assistantMsgId,
            isUser = false,
            text = "",
            isStreaming = true
        )

        val historySnapshot = _chatMessages.value
        _chatMessages.update { it + userMsg + placeholderMsg }
        _isChatStreaming.value = true

        val currentScanner = _scannerState.value
        val latestVerdict = (currentScanner.scanUiState as? ScanUiState.Success)?.result

        viewModelScope.launch {
            try {
                aiRepository.streamChatReply(
                    userMessage = textToSend,
                    history = historySnapshot,
                    pair = currentScanner.pairInput.ifBlank { "EUR/USD" },
                    timeframe = currentScanner.timeframe.label,
                    sessionSummary = _sessionSnapshot.value.activeSummaryLabel,
                    latestVerdict = latestVerdict,
                    chartBitmap = currentScanner.chartBitmap
                ).collect { accumulated ->
                    _chatMessages.update { list ->
                        list.map { msg ->
                            if (msg.id == assistantMsgId) {
                                msg.copy(text = accumulated, isStreaming = true)
                            } else {
                                msg
                            }
                        }
                    }
                }
                _chatMessages.update { list ->
                    list.map { msg ->
                        if (msg.id == assistantMsgId) msg.copy(isStreaming = false) else msg
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Chat streaming failed", e)
                val errText = e.localizedMessage ?: "Failed to get response from J.A.R.V.I.S."
                _chatError.value = errText
                _chatMessages.update { list ->
                    list.map { msg ->
                        if (msg.id == assistantMsgId) {
                            msg.copy(
                                text = "Error: $errText",
                                isStreaming = false
                            )
                        } else {
                            msg
                        }
                    }
                }
            } finally {
                _isChatStreaming.value = false
            }
        }
    }

    fun updateCalculatorInputs(
        balanceText: String = _calculatorState.value.balanceText,
        riskPercentText: String = _calculatorState.value.riskPercentText,
        stopLossText: String = _calculatorState.value.stopLossText,
        preset: InstrumentPreset = _calculatorState.value.preset,
        customPipValueText: String = _calculatorState.value.customPipValueText
    ) {
        val balance = balanceText.toDoubleOrNull() ?: 0.0
        val risk = riskPercentText.toDoubleOrNull() ?: 0.0
        val sl = stopLossText.toDoubleOrNull() ?: 0.0
        val customPip = customPipValueText.toDoubleOrNull()

        val result = PositionCalculator.calculate(
            accountBalance = balance,
            riskPercent = risk,
            stopLossPipsOrPoints = sl,
            preset = preset,
            customPipValuePerLot = customPip
        )

        _calculatorState.value = CalculatorState(
            balanceText = balanceText,
            riskPercentText = riskPercentText,
            stopLossText = stopLossText,
            preset = preset,
            customPipValueText = customPipValueText,
            result = result
        )
    }

    fun setLogFilter(filter: LogFilter) {
        _logFilter.value = filter
    }

    fun updateScanOutcome(scanId: Long, outcome: TradeOutcome) {
        viewModelScope.launch(Dispatchers.IO) {
            tradeLogRepository.updateOutcome(scanId, outcome)
        }
    }

    fun deleteScan(scanId: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            tradeLogRepository.deleteScan(scanId)
        }
    }

    fun clearAllScans() {
        viewModelScope.launch(Dispatchers.IO) {
            tradeLogRepository.clearAll()
        }
    }

    private fun decodeBitmapFromUri(uri: Uri): Bitmap? {
        return try {
            val resolver = getApplication<Application>().contentResolver
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val source = ImageDecoder.createSource(resolver, uri)
                ImageDecoder.decodeBitmap(source) { decoder, _, _ ->
                    decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                    decoder.isMutableRequired = true
                }
            } else {
                resolver.openInputStream(uri)?.use { stream ->
                    BitmapFactory.decodeStream(stream)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to decode chart URI", e)
            null
        }
    }
}
