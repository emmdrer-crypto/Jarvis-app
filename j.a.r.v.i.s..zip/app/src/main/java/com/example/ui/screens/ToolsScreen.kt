package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.model.InstrumentPreset
import com.example.model.SessionStatus
import com.example.ui.CalculatorState
import com.example.ui.components.TerminalCard
import com.example.ui.theme.GoodEmerald
import com.example.ui.theme.GoodEmeraldContainer
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonCyanContainer
import com.example.ui.theme.NoCrimson
import com.example.ui.theme.NoCrimsonContainer
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.TerminalBorder
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TerminalSurfaceElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WaitAmber
import com.example.ui.theme.WaitAmberContainer
import com.example.util.SessionSnapshot
import java.util.Locale

@Composable
fun ToolsScreen(
    calculatorState: CalculatorState,
    sessionSnapshot: SessionSnapshot,
    onBalanceChange: (String) -> Unit,
    onRiskPercentChange: (String) -> Unit,
    onStopLossChange: (String) -> Unit,
    onPresetSelect: (InstrumentPreset) -> Unit,
    onCustomPipValueChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBg)
    ) {
        val isExpandedTablet = maxWidth >= 840.dp

        if (isExpandedTablet) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    PositionSizeCalculatorCard(
                        state = calculatorState,
                        onBalanceChange = onBalanceChange,
                        onRiskPercentChange = onRiskPercentChange,
                        onStopLossChange = onStopLossChange,
                        onPresetSelect = onPresetSelect,
                        onCustomPipValueChange = onCustomPipValueChange
                    )
                }
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    SessionAndNewsClockCard(snapshot = sessionSnapshot)
                }
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                PositionSizeCalculatorCard(
                    state = calculatorState,
                    onBalanceChange = onBalanceChange,
                    onRiskPercentChange = onRiskPercentChange,
                    onStopLossChange = onStopLossChange,
                    onPresetSelect = onPresetSelect,
                    onCustomPipValueChange = onCustomPipValueChange
                )
                SessionAndNewsClockCard(snapshot = sessionSnapshot)
                Spacer(modifier = Modifier.height(8.dp))
            }
        }
    }
}

@Composable
private fun PositionSizeCalculatorCard(
    state: CalculatorState,
    onBalanceChange: (String) -> Unit,
    onRiskPercentChange: (String) -> Unit,
    onStopLossChange: (String) -> Unit,
    onPresetSelect: (InstrumentPreset) -> Unit,
    onCustomPipValueChange: (String) -> Unit
) {
    TerminalCard(borderColor = NeonCyan.copy(alpha = 0.45f)) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = Icons.Filled.Calculate,
                contentDescription = null,
                tint = NeonCyan,
                modifier = Modifier.size(24.dp)
            )
            Column {
                Text(
                    text = "POSITION SIZE & RISK CALCULATOR",
                    style = MaterialTheme.typography.titleSmall,
                    color = NeonCyan
                )
                Text(
                    text = "Calculate exact lot/unit size before entering",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Text(
            text = "INSTRUMENT TYPE",
            style = MaterialTheme.typography.labelSmall,
            color = TextSecondary
        )
        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            InstrumentPreset.entries.forEach { preset ->
                val selected = preset == state.preset
                Box(
                    modifier = Modifier
                        .heightIn(min = 44.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (selected) NeonCyanContainer else TerminalSurfaceElevated)
                        .border(
                            1.dp,
                            if (selected) NeonCyan else TerminalBorder,
                            RoundedCornerShape(10.dp)
                        )
                        .clickable { onPresetSelect(preset) }
                        .testTag("preset_${preset.name}")
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = preset.label,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (selected) NeonCyan else TextSecondary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            CalculatorTextField(
                value = state.balanceText,
                onValueChange = onBalanceChange,
                label = "Account Balance ($)",
                tag = "calc_balance_input",
                modifier = Modifier.weight(1f)
            )
            CalculatorTextField(
                value = state.riskPercentText,
                onValueChange = onRiskPercentChange,
                label = "Risk %",
                tag = "calc_risk_input",
                modifier = Modifier.weight(0.75f)
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Quick Risk % Presets
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("0.5", "1.0", "1.5", "2.0").forEach { pct ->
                val active = state.riskPercentText == pct
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(40.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (active) GoodEmeraldContainer else TerminalSurfaceElevated)
                        .border(
                            1.dp,
                            if (active) GoodEmerald else TerminalBorder,
                            RoundedCornerShape(10.dp)
                        )
                        .clickable { onRiskPercentChange(pct) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "$pct%",
                        style = MaterialTheme.typography.labelMedium,
                        color = if (active) GoodEmerald else TextSecondary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            CalculatorTextField(
                value = state.stopLossText,
                onValueChange = onStopLossChange,
                label = state.preset.stopLabel,
                tag = "calc_sl_input",
                modifier = Modifier.weight(1f)
            )
            CalculatorTextField(
                value = state.customPipValueText,
                onValueChange = onCustomPipValueChange,
                label = "Pip/Pt $ (Opt.)",
                tag = "calc_pip_val_input",
                modifier = Modifier.weight(0.85f)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        val res = state.result
        if (res != null) {
            val riskVal = state.riskPercentText.toDoubleOrNull() ?: 1.0
            val (riskFg, riskBg) = when {
                riskVal <= 1.0 -> GoodEmerald to GoodEmeraldContainer
                riskVal <= 2.0 -> WaitAmber to WaitAmberContainer
                else -> NoCrimson to NoCrimsonContainer
            }

            Surface(
                shape = RoundedCornerShape(14.dp),
                color = TerminalSurfaceElevated,
                border = BorderStroke(1.dp, NeonCyan.copy(alpha = 0.55f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("calc_result_card")
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "RECOMMENDED SIZE",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondary
                            )
                            Text(
                                text = String.format(Locale.US, "%.2f %s", res.positionSize, res.unitLabel),
                                style = MaterialTheme.typography.headlineMedium,
                                color = NeonCyan,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = res.subUnitDetail,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(riskBg)
                                .border(1.dp, riskFg.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                                .padding(horizontal = 8.dp, vertical = 5.dp)
                        ) {
                            Text(
                                text = res.riskLevelLabel,
                                style = MaterialTheme.typography.labelSmall,
                                color = riskFg
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        MetricMiniTile(
                            label = "MAX RISK",
                            value = String.format(Locale.US, "$%.2f", res.dollarRisk),
                            color = NoCrimson,
                            modifier = Modifier.weight(1f)
                        )
                        MetricMiniTile(
                            label = "1:2 TARGET",
                            value = String.format(Locale.US, "+$%.2f", res.target2RProfit),
                            color = GoodEmerald,
                            modifier = Modifier.weight(1f)
                        )
                        MetricMiniTile(
                            label = "1:3 TARGET",
                            value = String.format(Locale.US, "+$%.2f", res.target3RProfit),
                            color = NeonCyan,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        } else {
            Text(
                text = "Enter positive Balance, Risk %, and Stop-Loss to calculate safe position size.",
                style = MaterialTheme.typography.bodySmall,
                color = WaitAmber
            )
        }
    }
}

@Composable
private fun CalculatorTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    tag: String,
    modifier: Modifier = Modifier
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label, maxLines = 1) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        shape = RoundedCornerShape(12.dp),
        modifier = modifier.testTag(tag),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = NeonCyan,
            unfocusedBorderColor = TerminalBorder,
            focusedContainerColor = TerminalSurfaceElevated,
            unfocusedContainerColor = TerminalSurfaceElevated,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary,
            focusedLabelColor = NeonCyan,
            unfocusedLabelColor = TextSecondary
        )
    )
}

@Composable
private fun MetricMiniTile(
    label: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(TerminalSurface)
            .border(1.dp, TerminalBorder, RoundedCornerShape(10.dp))
            .padding(10.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = TextMuted
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.titleSmall,
            color = color
        )
    }
}

@Composable
private fun SessionAndNewsClockCard(snapshot: SessionSnapshot) {
    TerminalCard(borderColor = if (snapshot.isOverlapActive) GoodEmerald.copy(alpha = 0.6f) else TerminalBorder) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Public,
                    contentDescription = null,
                    tint = NeonCyan,
                    modifier = Modifier.size(24.dp)
                )
                Column {
                    Text(
                        text = "SESSION & VOLATILITY CLOCK",
                        style = MaterialTheme.typography.titleSmall,
                        color = NeonCyan
                    )
                    Text(
                        text = snapshot.localZoneLabel,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = snapshot.localTimeFormatted,
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary
                )
                Text(
                    text = snapshot.utcTimeFormatted,
                    style = MaterialTheme.typography.labelSmall,
                    color = NeonCyan
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Overlap Windows Highlight
        snapshot.overlaps.forEach { overlap ->
            val fg = if (overlap.isActive) GoodEmerald else TextSecondary
            val bg = if (overlap.isActive) GoodEmeraldContainer else TerminalSurfaceElevated
            val border = if (overlap.isActive) GoodEmerald else TerminalBorder

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(bg)
                    .border(1.dp, border, RoundedCornerShape(12.dp))
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Bolt,
                    contentDescription = null,
                    tint = if (overlap.isActive) GoodEmerald else TextMuted,
                    modifier = Modifier.size(22.dp)
                )
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = overlap.title,
                            style = MaterialTheme.typography.titleSmall,
                            color = fg
                        )
                        Text(
                            text = if (overlap.isActive) "LIVE OVERLAP" else "UPCOMING",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (overlap.isActive) GoodEmerald else TextMuted
                        )
                    }
                    Text(
                        text = overlap.utcWindow,
                        style = MaterialTheme.typography.labelSmall,
                        color = NeonCyan
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = overlap.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = "GLOBAL MARKET SESSIONS",
            style = MaterialTheme.typography.labelMedium,
            color = NeonCyan
        )
        Spacer(modifier = Modifier.height(8.dp))

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            snapshot.sessions.forEach { session ->
                val (statusText, statusColor, statusBg) = when (session.status) {
                    SessionStatus.OVERLAP_PEAK -> Triple("OVERLAP PEAK", GoodEmerald, GoodEmeraldContainer)
                    SessionStatus.OPEN -> Triple("OPEN", NeonCyan, NeonCyanContainer)
                    SessionStatus.CLOSED -> Triple("CLOSED", TextMuted, TerminalSurfaceElevated)
                }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(TerminalSurfaceElevated)
                        .border(
                            1.dp,
                            if (session.status != SessionStatus.CLOSED) statusColor.copy(alpha = 0.5f) else TerminalBorder,
                            RoundedCornerShape(12.dp)
                        )
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(9.dp)
                                    .clip(CircleShape)
                                    .background(statusColor)
                            )
                            Text(
                                text = session.name,
                                style = MaterialTheme.typography.titleMedium,
                                color = TextPrimary
                            )
                            Text(
                                text = "${session.localTimeRange} Local",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondary
                            )
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(statusBg)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = statusText,
                                style = MaterialTheme.typography.labelSmall,
                                color = statusColor
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = session.volatilityNote,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = session.statusDetail,
                            style = MaterialTheme.typography.labelSmall,
                            color = statusColor
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(
                imageVector = Icons.Filled.Schedule,
                contentDescription = null,
                tint = WaitAmber,
                modifier = Modifier.size(16.dp)
            )
            Text(
                text = "DAILY MACRO & NEWS VOLATILITY WINDOWS",
                style = MaterialTheme.typography.labelMedium,
                color = WaitAmber
            )
        }
        Spacer(modifier = Modifier.height(8.dp))

        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            snapshot.macroWindows.forEach { window ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (window.isNow) WaitAmberContainer else TerminalSurfaceElevated)
                        .border(
                            1.dp,
                            if (window.isNow) WaitAmber else TerminalBorder,
                            RoundedCornerShape(10.dp)
                        )
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${window.title} (${window.utcWindow})",
                            style = MaterialTheme.typography.labelMedium,
                            color = if (window.isNow) WaitAmber else TextPrimary
                        )
                        Text(
                            text = window.detail,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                    if (window.isNow) {
                        Text(
                            text = "ACTIVE",
                            style = MaterialTheme.typography.labelSmall,
                            color = WaitAmber
                        )
                    }
                }
            }
        }
    }
}
