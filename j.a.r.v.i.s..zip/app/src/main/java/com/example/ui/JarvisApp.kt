package com.example.ui

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.outlined.Build
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Radar
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.R
import com.example.overlay.ScreenShareOverlayService
import com.example.ui.screens.ScannerScreen
import com.example.ui.screens.ToolsScreen
import com.example.ui.screens.TradeLogScreen
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonCyanContainer
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.TerminalSurface
import com.example.ui.theme.TerminalSurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

const val ROUTE_SCANNER = "scanner"
const val ROUTE_TOOLS = "tools"
const val ROUTE_TRADE_LOG = "trade_log"

private data class JarvisNavDest(
    val route: String,
    val labelRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

private val Destinations = listOf(
    JarvisNavDest(
        route = ROUTE_SCANNER,
        labelRes = R.string.nav_scanner,
        selectedIcon = Icons.Filled.Radar,
        unselectedIcon = Icons.Outlined.Radar,
        testTag = "nav_scanner"
    ),
    JarvisNavDest(
        route = ROUTE_TOOLS,
        labelRes = R.string.nav_tools,
        selectedIcon = Icons.Filled.Build,
        unselectedIcon = Icons.Outlined.Build,
        testTag = "nav_tools"
    ),
    JarvisNavDest(
        route = ROUTE_TRADE_LOG,
        labelRes = R.string.nav_trade_log,
        selectedIcon = Icons.Filled.History,
        unselectedIcon = Icons.Outlined.History,
        testTag = "nav_trade_log"
    )
)

@Composable
fun JarvisApp(
    viewModel: JarvisViewModel = viewModel()
) {
    val context = LocalContext.current
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: ROUTE_SCANNER

    val scannerState by viewModel.scannerState.collectAsStateWithLifecycle()
    val sessionSnapshot by viewModel.sessionSnapshot.collectAsStateWithLifecycle()
    val screenShareState by viewModel.screenShareState.collectAsStateWithLifecycle()
    val chatMessages by viewModel.chatMessages.collectAsStateWithLifecycle()
    val chatInput by viewModel.chatInput.collectAsStateWithLifecycle()
    val isChatStreaming by viewModel.isChatStreaming.collectAsStateWithLifecycle()
    val calculatorState by viewModel.calculatorState.collectAsStateWithLifecycle()
    val allScans by viewModel.allScans.collectAsStateWithLifecycle()
    val filteredScans by viewModel.filteredScans.collectAsStateWithLifecycle()
    val logFilter by viewModel.logFilter.collectAsStateWithLifecycle()

    var showOverlayPermissionDialog by remember { mutableStateOf(false) }

    val mediaProjectionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val startIntent = ScreenShareOverlayService.createStartIntent(
                context = context,
                resultCode = result.resultCode,
                data = result.data!!
            )
            ContextCompat.startForegroundService(context, startIntent)
        }
    }

    val launchMediaProjectionPrompt: () -> Unit = {
        val mpManager = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjectionLauncher.launch(mpManager.createScreenCaptureIntent())
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ ->
        // Proceed to MediaProjection prompt regardless so core screen share still starts
        launchMediaProjectionPrompt()
    }

    val startScreenShareFlow: () -> Unit = {
        if (!Settings.canDrawOverlays(context)) {
            showOverlayPermissionDialog = true
        } else if (
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            launchMediaProjectionPrompt()
        }
    }

    val stopScreenShareFlow: () -> Unit = {
        context.startService(ScreenShareOverlayService.createStopIntent(context))
    }

    if (showOverlayPermissionDialog) {
        AlertDialog(
            onDismissRequest = { showOverlayPermissionDialog = false },
            containerColor = TerminalSurfaceElevated,
            title = {
                Text(
                    text = stringResource(R.string.overlay_permission_title),
                    color = TextPrimary
                )
            },
            text = {
                Text(
                    text = stringResource(R.string.overlay_permission_body),
                    color = TextSecondary
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showOverlayPermissionDialog = false
                        val intent = Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:${context.packageName}")
                        )
                        context.startActivity(intent)
                    }
                ) {
                    Text(stringResource(R.string.overlay_permission_confirm), color = NeonCyan)
                }
            },
            dismissButton = {
                TextButton(onClick = { showOverlayPermissionDialog = false }) {
                    Text(stringResource(R.string.overlay_permission_cancel), color = TextSecondary)
                }
            }
        )
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBg)
    ) {
        val useNavRail = maxWidth >= 600.dp

        val navigateTo: (String) -> Unit = { route ->
            navController.navigate(route) {
                popUpTo(navController.graph.findStartDestination().id) {
                    saveState = true
                }
                launchSingleTop = true
                restoreState = true
            }
        }

        Scaffold(
            containerColor = ObsidianBg,
            contentWindowInsets = WindowInsets.safeDrawing,
            bottomBar = {
                if (!useNavRail) {
                    NavigationBar(
                        containerColor = TerminalSurface,
                        tonalElevation = 6.dp
                    ) {
                        Destinations.forEach { dest ->
                            val selected = currentRoute == dest.route
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateTo(dest.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                        contentDescription = stringResource(dest.labelRes)
                                    )
                                },
                                label = {
                                    Text(
                                        text = stringResource(dest.labelRes),
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = NeonCyan,
                                    selectedTextColor = NeonCyan,
                                    indicatorColor = NeonCyanContainer,
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary
                                ),
                                modifier = Modifier.testTag(dest.testTag)
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useNavRail) {
                    NavigationRail(
                        containerColor = TerminalSurface,
                        modifier = Modifier.fillMaxHeight()
                    ) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "J.R.V",
                            style = MaterialTheme.typography.labelMedium,
                            color = NeonCyan,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Destinations.forEach { dest ->
                            val selected = currentRoute == dest.route
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateTo(dest.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                        contentDescription = stringResource(dest.labelRes)
                                    )
                                },
                                label = {
                                    Text(
                                        text = stringResource(dest.labelRes),
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = NeonCyan,
                                    selectedTextColor = NeonCyan,
                                    indicatorColor = NeonCyanContainer,
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary
                                ),
                                modifier = Modifier.testTag(dest.testTag)
                            )
                        }
                    }
                }

                NavHost(
                    navController = navController,
                    startDestination = ROUTE_SCANNER,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxSize()
                ) {
                    composable(ROUTE_SCANNER) {
                        ScannerScreen(
                            scannerState = scannerState,
                            sessionSnapshot = sessionSnapshot,
                            screenShareState = screenShareState,
                            chatMessages = chatMessages,
                            chatInput = chatInput,
                            isChatStreaming = isChatStreaming,
                            onPairChange = viewModel::updatePair,
                            onTimeframeSelect = viewModel::selectTimeframe,
                            onToggleHigherTimeframe = viewModel::toggleHigherTimeframe,
                            onToggleMinRiskReward = viewModel::toggleMinRiskReward,
                            onToggleClearSlTp = viewModel::toggleClearSlTp,
                            onToggleNoNews = viewModel::toggleNoHighImpactNews,
                            onTraderNoteChange = viewModel::updateTraderNote,
                            onChartPicked = viewModel::onChartSelected,
                            onClearChart = viewModel::clearChart,
                            onScanTrade = viewModel::scanTrade,
                            onStartScreenShare = startScreenShareFlow,
                            onStopScreenShare = stopScreenShareFlow,
                            onChatInputChange = viewModel::updateChatInput,
                            onSendChat = viewModel::sendChatMessage
                        )
                    }
                    composable(ROUTE_TOOLS) {
                        ToolsScreen(
                            calculatorState = calculatorState,
                            sessionSnapshot = sessionSnapshot,
                            onBalanceChange = { viewModel.updateCalculatorInputs(balanceText = it) },
                            onRiskPercentChange = { viewModel.updateCalculatorInputs(riskPercentText = it) },
                            onStopLossChange = { viewModel.updateCalculatorInputs(stopLossText = it) },
                            onPresetSelect = { viewModel.updateCalculatorInputs(preset = it) },
                            onCustomPipValueChange = { viewModel.updateCalculatorInputs(customPipValueText = it) }
                        )
                    }
                    composable(ROUTE_TRADE_LOG) {
                        TradeLogScreen(
                            allScans = allScans,
                            filteredScans = filteredScans,
                            selectedFilter = logFilter,
                            onSelectFilter = viewModel::setLogFilter,
                            onUpdateOutcome = viewModel::updateScanOutcome,
                            onDeleteScan = viewModel::deleteScan,
                            onClearAll = viewModel::clearAllScans
                        )
                    }
                }
            }
        }
    }
}
