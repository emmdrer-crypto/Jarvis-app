package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ObsidianBg = Color(0xFF080B10)
val TerminalSurface = Color(0xFF0F1520)
val TerminalSurfaceElevated = Color(0xFF161F2E)
val TerminalSurfaceHigh = Color(0xFF1C273A)
val TerminalBorder = Color(0xFF233247)
val TerminalBorderBright = Color(0xFF2F4563)

val NeonCyan = Color(0xFF00E5FF)
val NeonCyanContainer = Color(0xFF0A2E38)
val ElectricBlue = Color(0xFF38BDF8)

val GoodEmerald = Color(0xFF00E676)
val GoodEmeraldContainer = Color(0xFF072B1D)

val WaitAmber = Color(0xFFFFB300)
val WaitAmberContainer = Color(0xFF332304)

val NoCrimson = Color(0xFFFF3D57)
val NoCrimsonContainer = Color(0xFF380C16)

val TextPrimary = Color(0xFFF1F5FB)
val TextSecondary = Color(0xFF94A7C2)
val TextMuted = Color(0xFF5D708A)
